  window.__INITIAL_MOVIES__ = [{"id":1,"title":"Casablanca","year":1942,"rating":8.5,"genre":"romance","genre_label":"Romantic","note":"Wartime Casablanca, a love re-lit and let go.","rank_in_genre":1},{"id":2,"title":"Before Sunrise","year":1995,"rating":8.1,"genre":"romance","genre_label":"Romantic","note":"One night in Vienna between two strangers on a train.","rank_in_genre":2},{"id":3,"title":"Eternal Sunshine of the Spotless Mind","year":2004,"rating":8.3,"genre":"romance","genre_label":"Romantic","note":"A couple erases each other from memory, and finds their way back.","rank_in_genre":3},{"id":4,"title":"Amélie","year":2001,"rating":8.3,"genre":"romance","genre_label":"Romantic","note":"A shy Parisian waitress engineers small joys for strangers.","rank_in_genre":4},{"id":5,"title":"La La Land","year":2016,"rating":8,"genre":"romance","genre_label":"Romantic","note":"An actress and a jazz pianist chase two dreams at once.","rank_in_genre":5},{"id":6,"title":"Roman Holiday","year":1953,"rating":7.9,"genre":"romance","genre_label":"Romantic","note":"A runaway princess and a reporter share one day in Rome.","rank_in_genre":6},{"id":7,"title":"Titanic","year":1997,"rating":7.9,"genre":"romance","genre_label":"Romantic","note":"First class meets steerage aboard a ship that won't reach New York.","rank_in_genre":7},{"id":8,"title":"The Notebook","year":2004,"rating":7.8,"genre":"romance","genre_label":"Romantic","note":"A summer romance, a letter a year, a lifetime of waiting.","rank_in_genre":8},{"id":9,"title":"Pride & Prejudice","year":2005,"rating":7.8,"genre":"romance","genre_label":"Romantic","note":"Wit, pride, and a very long walk across the English countryside.","rank_in_genre":9},{"id":10,"title":"When Harry Met Sally...","year":1989,"rating":7.6,"genre":"romance","genre_label":"Romantic","note":"Can friends really stay just friends? Twelve years say otherwise.","rank_in_genre":10},{"id":11,"title":"Gone with the Wind","year":1939,"rating":8.2,"genre":"romance","genre_label":"Romantic","note":"A headstrong Southern belle survives war, ruin, and one impossible love.","rank_in_genre":11},{"id":12,"title":"It Happened One Night","year":1934,"rating":8.1,"genre":"romance","genre_label":"Romantic","note":"A runaway heiress and a wisecracking reporter share a bus ride and a blanket wall.","rank_in_genre":12},{"id":13,"title":"The Princess Bride","year":1987,"rating":8,"genre":"romance","genre_label":"Romantic","note":"True love, a farm boy turned pirate, and a storybook told just right.","rank_in_genre":13},{"id":14,"title":"Before Sunset","year":2004,"rating":8,"genre":"romance","genre_label":"Romantic","note":"Nine years later, one Paris afternoon to find out what almost was.","rank_in_genre":14},{"id":15,"title":"Her","year":2013,"rating":8,"genre":"romance","genre_label":"Romantic","note":"A lonely writer falls for the voice running his operating system.","rank_in_genre":15},{"id":16,"title":"Silver Linings Playbook","year":2012,"rating":7.7,"genre":"romance","genre_label":"Romantic","note":"Two people rebuilding themselves stumble into rebuilding something together.","rank_in_genre":16},{"id":17,"title":"500 Days of Summer","year":2009,"rating":7.7,"genre":"romance","genre_label":"Romantic","note":"Not a love story — a story about a love, told out of order.","rank_in_genre":17},{"id":18,"title":"The Fault in Our Stars","year":2014,"rating":7.7,"genre":"romance","genre_label":"Romantic","note":"Two teenagers in cancer support group find a romance neither expected.","rank_in_genre":18},{"id":19,"title":"Brokeback Mountain","year":2005,"rating":7.7,"genre":"romance","genre_label":"Romantic","note":"Two ranch hands share a summer that shapes the rest of their lives.","rank_in_genre":19},{"id":20,"title":"A Star Is Born","year":2018,"rating":7.6,"genre":"romance","genre_label":"Romantic","note":"A fading star and a rising one fall for each other as their paths cross.","rank_in_genre":20},{"id":21,"title":"Moulin Rouge!","year":2001,"rating":7.6,"genre":"romance","genre_label":"Romantic","note":"A poet and a courtesan sing their way through 1900s Paris nightlife.","rank_in_genre":21},{"id":22,"title":"Notting Hill","year":1999,"rating":7.2,"genre":"romance","genre_label":"Romantic","note":"A bookshop owner falls for the most famous actress in the world.","rank_in_genre":22},{"id":23,"title":"Ghost","year":1990,"rating":7.1,"genre":"romance","genre_label":"Romantic","note":"A murdered man tries to protect the woman he loves from beyond.","rank_in_genre":23},{"id":24,"title":"Pretty Woman","year":1990,"rating":7,"genre":"romance","genre_label":"Romantic","note":"A businessman hires a companion for a week, and neither expects what follows.","rank_in_genre":24},{"id":25,"title":"Crazy Rich Asians","year":2018,"rating":6.9,"genre":"romance","genre_label":"Romantic","note":"A trip to meet the family turns into a crash course in old money.","rank_in_genre":25},{"id":26,"title":"Sleepless in Seattle","year":1993,"rating":6.8,"genre":"romance","genre_label":"Romantic","note":"A radio call-in leads a widower's son to try to find him a new match.","rank_in_genre":26},{"id":27,"title":"You've Got Mail","year":1998,"rating":6.6,"genre":"romance","genre_label":"Romantic","note":"Two rival booksellers fall for each other anonymously online.","rank_in_genre":27},{"id":28,"title":"Call Me by Your Name","year":2017,"rating":7.9,"genre":"romance","genre_label":"Romantic","note":"A summer in Italy changes a teenager and a visiting scholar forever.","rank_in_genre":28},{"id":29,"title":"Atonement","year":2007,"rating":7.8,"genre":"romance","genre_label":"Romantic","note":"A childhood lie tears two lovers apart for the rest of their lives.","rank_in_genre":29},{"id":30,"title":"Jerry Maguire","year":1996,"rating":7.3,"genre":"romance","genre_label":"Romantic","note":"A sports agent's crisis of conscience costs him everything but the right people.","rank_in_genre":30},{"id":31,"title":"Dirty Dancing","year":1987,"rating":6.9,"genre":"romance","genre_label":"Romantic","note":"A summer resort, a dance instructor, and a girl who won't be put in a corner.","rank_in_genre":31},{"id":32,"title":"Me Before You","year":2016,"rating":7.4,"genre":"romance","genre_label":"Romantic","note":"A free-spirited caretaker changes what a paralyzed man believes his life can be.","rank_in_genre":32},{"id":33,"title":"The Time Traveler's Wife","year":2009,"rating":7.1,"genre":"romance","genre_label":"Romantic","note":"A love story complicated by a man who can't control when he disappears.","rank_in_genre":33},{"id":34,"title":"P.S. I Love You","year":2007,"rating":7.1,"genre":"romance","genre_label":"Romantic","note":"A widow keeps receiving letters her late husband wrote before he died.","rank_in_genre":34},{"id":35,"title":"A Walk to Remember","year":2002,"rating":7.3,"genre":"romance","genre_label":"Romantic","note":"A rebellious teen falls for the preacher's daughter he was set to mock.","rank_in_genre":35},{"id":36,"title":"Bridget Jones's Diary","year":2001,"rating":6.7,"genre":"romance","genre_label":"Romantic","note":"A chaotic year of diary entries, bad dates, and two very different men.","rank_in_genre":36},{"id":37,"title":"Love Actually","year":2003,"rating":7.6,"genre":"romance","genre_label":"Romantic","note":"Ten intertwined London love stories collide in the run-up to Christmas.","rank_in_genre":37},{"id":38,"title":"10 Things I Hate About You","year":1999,"rating":7.3,"genre":"romance","genre_label":"Romantic","note":"A bet to date the unapproachable older sister turns into something real.","rank_in_genre":38},{"id":39,"title":"The Wedding Singer","year":1998,"rating":6.8,"genre":"romance","genre_label":"Romantic","note":"A jilted wedding singer and an engaged waitress fall for each other instead.","rank_in_genre":39},{"id":40,"title":"My Big Fat Greek Wedding","year":2002,"rating":6.6,"genre":"romance","genre_label":"Romantic","note":"A woman falls for a non-Greek man, and her enormous family has opinions.","rank_in_genre":40},{"id":41,"title":"Beauty and the Beast","year":1991,"rating":8,"genre":"romance","genre_label":"Romantic","note":"A bookish young woman sees past a cursed prince's monstrous exterior.","rank_in_genre":41},{"id":42,"title":"Anna Karenina","year":2012,"rating":6.6,"genre":"romance","genre_label":"Romantic","note":"A married aristocrat's affair unravels her place in Russian high society.","rank_in_genre":42},{"id":43,"title":"Cyrano de Bergerac","year":1990,"rating":8,"genre":"romance","genre_label":"Romantic","note":"A brilliant, big-nosed poet woos a woman on another man's behalf.","rank_in_genre":43},{"id":44,"title":"In the Mood for Love","year":2000,"rating":8.1,"genre":"romance","genre_label":"Romantic","note":"Two neighbors, both married to unfaithful spouses, grow close without ever crossing a line.","rank_in_genre":44},{"id":45,"title":"Portrait of a Lady on Fire","year":2019,"rating":8.1,"genre":"romance","genre_label":"Romantic","note":"A painter and her reluctant subject fall for each other on an isolated island.","rank_in_genre":45},{"id":46,"title":"Blue Valentine","year":2010,"rating":7.4,"genre":"romance","genre_label":"Romantic","note":"A marriage's beginning and its unraveling, told side by side.","rank_in_genre":46},{"id":47,"title":"The Bridges of Madison County","year":1995,"rating":7.3,"genre":"romance","genre_label":"Romantic","note":"A photographer and a farmer's wife share four days that outlast a lifetime.","rank_in_genre":47},{"id":48,"title":"An Affair to Remember","year":1957,"rating":7.7,"genre":"romance","genre_label":"Romantic","note":"Two engaged strangers fall for each other on a transatlantic crossing.","rank_in_genre":48},{"id":49,"title":"Breakfast at Tiffany's","year":1961,"rating":7.6,"genre":"romance","genre_label":"Romantic","note":"A free-spirited socialite and her new neighbor circle each other in New York.","rank_in_genre":49},{"id":50,"title":"West Side Story","year":1961,"rating":7.6,"genre":"romance","genre_label":"Romantic","note":"Star-crossed lovers from rival gangs sing their way toward tragedy.","rank_in_genre":50},{"id":51,"title":"Doctor Zhivago","year":1965,"rating":7.9,"genre":"romance","genre_label":"Romantic","note":"A doctor and poet's love survives revolution, exile, and war.","rank_in_genre":51},{"id":52,"title":"The English Patient","year":1996,"rating":7.4,"genre":"romance","genre_label":"Romantic","note":"A dying man's wartime love affair is pieced together from his memories.","rank_in_genre":52},{"id":53,"title":"Punch-Drunk Love","year":2002,"rating":7.3,"genre":"romance","genre_label":"Romantic","note":"A socially awkward man's chaotic life is steadied by an unexpected romance.","rank_in_genre":53},{"id":54,"title":"The Great Gatsby","year":2013,"rating":7.2,"genre":"romance","genre_label":"Romantic","note":"A mysterious millionaire's parties are all aimed at winning back one woman.","rank_in_genre":54},{"id":55,"title":"The Vow","year":2012,"rating":6.7,"genre":"romance","genre_label":"Romantic","note":"A husband tries to make his wife fall in love with him again after amnesia.","rank_in_genre":55},{"id":56,"title":"Chocolat","year":2000,"rating":7.2,"genre":"romance","genre_label":"Romantic","note":"A chocolatier's arrival stirs up a rigid French village, and one man in particular.","rank_in_genre":56},{"id":57,"title":"Sense and Sensibility","year":1995,"rating":7.7,"genre":"romance","genre_label":"Romantic","note":"Two sisters navigate love and heartbreak after their family's fortune collapses.","rank_in_genre":57},{"id":58,"title":"Shakespeare in Love","year":1998,"rating":7.1,"genre":"romance","genre_label":"Romantic","note":"A struggling playwright finds his muse in a woman disguised as an actor.","rank_in_genre":58},{"id":59,"title":"The Age of Innocence","year":1993,"rating":7.3,"genre":"romance","genre_label":"Romantic","note":"A man engaged to one woman falls for another in strict 1870s New York society.","rank_in_genre":59},{"id":60,"title":"Emma.","year":2020,"rating":6.9,"genre":"romance","genre_label":"Romantic","note":"A meddling matchmaker keeps arranging everyone's love life but her own.","rank_in_genre":60},{"id":61,"title":"The Dark Knight","year":2008,"rating":9,"genre":"action","genre_label":"Action","note":"Gotham's white knight and its clown prince collide.","rank_in_genre":1},{"id":62,"title":"The Lord of the Rings: The Return of the King","year":2003,"rating":9,"genre":"action","genre_label":"Action","note":"The last march on Mordor, and the ring's final mile.","rank_in_genre":2},{"id":63,"title":"The Lord of the Rings: The Fellowship of the Ring","year":2001,"rating":8.9,"genre":"action","genre_label":"Action","note":"Nine walkers set out from the Shire to save Middle-earth.","rank_in_genre":3},{"id":64,"title":"The Lord of the Rings: The Two Towers","year":2002,"rating":8.8,"genre":"action","genre_label":"Action","note":"The fellowship splits, and Helm's Deep braces for siege.","rank_in_genre":4},{"id":65,"title":"Star Wars: Episode V — The Empire Strikes Back","year":1980,"rating":8.7,"genre":"action","genre_label":"Action","note":"The rebellion scatters, and a father's shadow grows long.","rank_in_genre":5},{"id":66,"title":"Gladiator","year":2000,"rating":8.5,"genre":"action","genre_label":"Action","note":"A general turned slave turned arena legend, out for Rome.","rank_in_genre":6},{"id":67,"title":"Léon: The Professional","year":1994,"rating":8.5,"genre":"action","genre_label":"Action","note":"A hitman and an orphaned girl form an unlikely partnership.","rank_in_genre":7},{"id":68,"title":"Raiders of the Lost Ark","year":1981,"rating":8.4,"genre":"action","genre_label":"Action","note":"An archaeologist races the Nazis to a relic that melts faces.","rank_in_genre":8},{"id":69,"title":"Die Hard","year":1988,"rating":8.2,"genre":"action","genre_label":"Action","note":"One cop, bare feet, and a skyscraper full of thieves.","rank_in_genre":9},{"id":70,"title":"Mad Max: Fury Road","year":2015,"rating":8.1,"genre":"action","genre_label":"Action","note":"A wasteland chase that barely stops for two hours straight.","rank_in_genre":10},{"id":71,"title":"Star Wars: Episode IV — A New Hope","year":1977,"rating":8.6,"genre":"action","genre_label":"Action","note":"A farm boy, a smuggler, and a princess take on an empire.","rank_in_genre":11},{"id":72,"title":"Star Wars: Episode VI — Return of the Jedi","year":1983,"rating":8.3,"genre":"action","genre_label":"Action","note":"The rebellion's final push, and one last chance to save a father.","rank_in_genre":12},{"id":73,"title":"Aliens","year":1986,"rating":8.4,"genre":"action","genre_label":"Action","note":"Ripley returns to the derelict colony, this time with marines.","rank_in_genre":13},{"id":74,"title":"Terminator 2: Judgment Day","year":1991,"rating":8.6,"genre":"action","genre_label":"Action","note":"This time the machine is the one protecting John Connor.","rank_in_genre":14},{"id":75,"title":"Heat","year":1995,"rating":8.3,"genre":"action","genre_label":"Action","note":"A cop and a career thief study each other across one long LA night.","rank_in_genre":15},{"id":76,"title":"Kill Bill: Vol. 1","year":2003,"rating":8.2,"genre":"action","genre_label":"Action","note":"A former assassin wakes from a coma with one very specific list.","rank_in_genre":16},{"id":77,"title":"Casino Royale","year":2006,"rating":8,"genre":"action","genre_label":"Action","note":"Bond's first mission puts him at a very high-stakes poker table.","rank_in_genre":17},{"id":78,"title":"The Bourne Ultimatum","year":2007,"rating":8,"genre":"action","genre_label":"Action","note":"An amnesiac agent closes in on the truth about who made him.","rank_in_genre":18},{"id":79,"title":"Inglourious Basterds","year":2009,"rating":8.3,"genre":"action","genre_label":"Action","note":"A team of soldiers and a cinema owner plot revenge on the same night.","rank_in_genre":19},{"id":80,"title":"Django Unchained","year":2012,"rating":8.4,"genre":"action","genre_label":"Action","note":"A freed slave turned bounty hunter rides south to find his wife.","rank_in_genre":20},{"id":81,"title":"Skyfall","year":2012,"rating":7.8,"genre":"action","genre_label":"Action","note":"Bond's past catches up with him just as MI6 comes under attack.","rank_in_genre":21},{"id":82,"title":"The Avengers","year":2012,"rating":8,"genre":"action","genre_label":"Action","note":"Earth's mightiest heroes are forced to team up for the first time.","rank_in_genre":22},{"id":83,"title":"John Wick","year":2014,"rating":7.4,"genre":"action","genre_label":"Action","note":"A retired hitman is pulled back in over a stolen car and a dog.","rank_in_genre":23},{"id":84,"title":"Kingsman: The Secret Service","year":2014,"rating":7.7,"genre":"action","genre_label":"Action","note":"A street kid gets recruited into a very posh spy agency.","rank_in_genre":24},{"id":85,"title":"Predator","year":1987,"rating":7.8,"genre":"action","genre_label":"Action","note":"A commando team in the jungle realizes they're the ones being hunted.","rank_in_genre":25},{"id":86,"title":"The Matrix Reloaded","year":2003,"rating":7.2,"genre":"action","genre_label":"Action","note":"Neo pushes his newfound powers further as the machine war escalates.","rank_in_genre":26},{"id":87,"title":"Speed","year":1994,"rating":7.3,"genre":"action","genre_label":"Action","note":"A bus can't slow below 50 mph or a bomb on board goes off.","rank_in_genre":27},{"id":88,"title":"Face/Off","year":1997,"rating":7.3,"genre":"action","genre_label":"Action","note":"An agent and a terrorist literally trade faces to stop a bombing.","rank_in_genre":28},{"id":89,"title":"True Lies","year":1994,"rating":7.2,"genre":"action","genre_label":"Action","note":"A secret agent's cover life at home collides with his real job.","rank_in_genre":29},{"id":90,"title":"The Rock","year":1996,"rating":7.4,"genre":"action","genre_label":"Action","note":"An ex-convict and a chemist must retake Alcatraz from rogue soldiers.","rank_in_genre":30},{"id":91,"title":"Con Air","year":1997,"rating":6.9,"genre":"action","genre_label":"Action","note":"A prisoner transport flight turns into a hijacking at 30,000 feet.","rank_in_genre":31},{"id":92,"title":"Rambo: First Blood","year":1982,"rating":7.6,"genre":"action","genre_label":"Action","note":"A traumatized veteran is pushed too far by a small-town sheriff.","rank_in_genre":32},{"id":93,"title":"Total Recall","year":1990,"rating":7.5,"genre":"action","genre_label":"Action","note":"A man's implanted Mars vacation memory turns out to be very real.","rank_in_genre":33},{"id":94,"title":"RoboCop","year":1987,"rating":7.6,"genre":"action","genre_label":"Action","note":"A slain officer is rebuilt as a cyborg enforcer for a crime-ridden city.","rank_in_genre":34},{"id":95,"title":"Lethal Weapon","year":1987,"rating":7.6,"genre":"action","genre_label":"Action","note":"A reckless cop and his steady new partner take on a drug ring.","rank_in_genre":35},{"id":96,"title":"Point Break","year":1991,"rating":7.3,"genre":"action","genre_label":"Action","note":"An FBI agent infiltrates a gang of surfers who moonlight as bank robbers.","rank_in_genre":36},{"id":97,"title":"The Fugitive","year":1993,"rating":7.8,"genre":"action","genre_label":"Action","note":"A wrongly convicted doctor races to prove his innocence while on the run.","rank_in_genre":37},{"id":98,"title":"Mission: Impossible – Fallout","year":2018,"rating":7.7,"genre":"action","genre_label":"Action","note":"A recovered set of plutonium cores puts Hunt's whole team on the clock.","rank_in_genre":38},{"id":99,"title":"Mission: Impossible – Ghost Protocol","year":2011,"rating":7.4,"genre":"action","genre_label":"Action","note":"Disavowed and framed, Hunt's team goes rogue to clear their names.","rank_in_genre":39},{"id":100,"title":"The Bourne Identity","year":2002,"rating":7.9,"genre":"action","genre_label":"Action","note":"An amnesiac pulled from the sea starts uncovering a deadly past.","rank_in_genre":40},{"id":101,"title":"The Dark Knight Rises","year":2012,"rating":8.4,"genre":"action","genre_label":"Action","note":"Batman returns to face a masked mercenary threatening to level Gotham.","rank_in_genre":41},{"id":102,"title":"Logan","year":2017,"rating":8.1,"genre":"action","genre_label":"Action","note":"An aging Wolverine protects a young mutant on one last, brutal run.","rank_in_genre":42},{"id":103,"title":"Kill Bill: Vol. 2","year":2004,"rating":8,"genre":"action","genre_label":"Action","note":"The Bride's revenge tour reaches the man at the top of her list.","rank_in_genre":43},{"id":104,"title":"V for Vendetta","year":2005,"rating":8.1,"genre":"action","genre_label":"Action","note":"A masked vigilante sparks a rebellion against a totalitarian government.","rank_in_genre":44},{"id":105,"title":"300","year":2006,"rating":7.7,"genre":"action","genre_label":"Action","note":"Three hundred Spartans make a legendary last stand at Thermopylae.","rank_in_genre":45},{"id":106,"title":"Sicario","year":2015,"rating":7.6,"genre":"action","genre_label":"Action","note":"An FBI agent is drawn into a covert war against a drug cartel.","rank_in_genre":46},{"id":107,"title":"The Raid: Redemption","year":2011,"rating":7.6,"genre":"action","genre_label":"Action","note":"A rookie cop fights floor by floor through a crime lord's tower.","rank_in_genre":47},{"id":108,"title":"Man on Fire","year":2004,"rating":7.7,"genre":"action","genre_label":"Action","note":"A burned-out bodyguard goes to war after his young charge is kidnapped.","rank_in_genre":48},{"id":109,"title":"Unforgiven","year":1992,"rating":8.2,"genre":"action","genre_label":"Action","note":"A retired gunslinger takes one last job that reopens old wounds.","rank_in_genre":49},{"id":110,"title":"Enter the Dragon","year":1973,"rating":7.6,"genre":"action","genre_label":"Action","note":"A martial artist enters a deadly tournament to expose a crime lord.","rank_in_genre":50},{"id":111,"title":"The Wild Bunch","year":1969,"rating":7.9,"genre":"action","genre_label":"Action","note":"An aging outlaw gang plans one final robbery as the Old West closes in.","rank_in_genre":51},{"id":112,"title":"Wonder Woman","year":2017,"rating":7.3,"genre":"action","genre_label":"Action","note":"An Amazon warrior leaves her island to fight in the First World War.","rank_in_genre":52},{"id":113,"title":"Black Panther","year":2018,"rating":7.3,"genre":"action","genre_label":"Action","note":"A new king defends Wakanda's secrets from a challenger with a rightful claim.","rank_in_genre":53},{"id":114,"title":"Spider-Man: No Way Home","year":2021,"rating":8.2,"genre":"action","genre_label":"Action","note":"A spell gone wrong tears open the multiverse and its villains.","rank_in_genre":54},{"id":115,"title":"Top Gun: Maverick","year":2022,"rating":8.2,"genre":"action","genre_label":"Action","note":"A legendary pilot trains a new generation for an impossible mission.","rank_in_genre":55},{"id":116,"title":"Mad Max 2: The Road Warrior","year":1981,"rating":7.6,"genre":"action","genre_label":"Action","note":"A wasteland drifter defends a fuel refinery from a marauding gang.","rank_in_genre":56},{"id":117,"title":"The Terminator","year":1984,"rating":8.1,"genre":"action","genre_label":"Action","note":"A machine is sent back to erase a woman before her son is born.","rank_in_genre":57},{"id":118,"title":"Batman Begins","year":2005,"rating":8.2,"genre":"action","genre_label":"Action","note":"A traumatized billionaire trains abroad before becoming Gotham's protector.","rank_in_genre":58},{"id":119,"title":"Air Force One","year":1997,"rating":6.5,"genre":"action","genre_label":"Action","note":"The president fights back after hijackers seize control of his own plane.","rank_in_genre":59},{"id":120,"title":"Rambo","year":2008,"rating":6.9,"genre":"action","genre_label":"Action","note":"A retired soldier is pulled back into combat to rescue kidnapped aid workers.","rank_in_genre":60},{"id":121,"title":"Inception","year":2010,"rating":8.8,"genre":"scifi","genre_label":"Science Fiction","note":"A heist team plants an idea, four dream-layers deep.","rank_in_genre":1},{"id":122,"title":"Interstellar","year":2014,"rating":8.7,"genre":"scifi","genre_label":"Science Fiction","note":"A father crosses a wormhole to save the world his daughter inherits.","rank_in_genre":2},{"id":123,"title":"The Matrix","year":1999,"rating":8.7,"genre":"scifi","genre_label":"Science Fiction","note":"A red pill, a black cat, and a war for the real world.","rank_in_genre":3},{"id":124,"title":"Terminator 2: Judgment Day","year":1991,"rating":8.6,"genre":"scifi","genre_label":"Science Fiction","note":"This time the machine is the one protecting John Connor.","rank_in_genre":4},{"id":125,"title":"Alien","year":1979,"rating":8.5,"genre":"scifi","genre_label":"Science Fiction","note":"A cargo ship, a distress signal, and something that shouldn't exist.","rank_in_genre":5},{"id":126,"title":"Back to the Future","year":1985,"rating":8.5,"genre":"scifi","genre_label":"Science Fiction","note":"A DeLorean, 1.21 gigawatts, and a very risky family reunion.","rank_in_genre":6},{"id":127,"title":"2001: A Space Odyssey","year":1968,"rating":8.3,"genre":"scifi","genre_label":"Science Fiction","note":"Human evolution, told through a monolith and a rogue AI.","rank_in_genre":7},{"id":128,"title":"Jurassic Park","year":1993,"rating":8.2,"genre":"scifi","genre_label":"Science Fiction","note":"Cloned dinosaurs, one storm, and a park that isn't ready.","rank_in_genre":8},{"id":129,"title":"Blade Runner 2049","year":2017,"rating":8,"genre":"scifi","genre_label":"Science Fiction","note":"A new blade runner unearths a secret that could end everything.","rank_in_genre":9},{"id":130,"title":"Arrival","year":2016,"rating":7.9,"genre":"scifi","genre_label":"Science Fiction","note":"A linguist learns an alien language, and time stops behaving.","rank_in_genre":10},{"id":131,"title":"Star Wars: Episode V — The Empire Strikes Back","year":1980,"rating":8.7,"genre":"scifi","genre_label":"Science Fiction","note":"The rebellion scatters, and a father's shadow grows long.","rank_in_genre":11},{"id":132,"title":"Blade Runner","year":1982,"rating":8.1,"genre":"scifi","genre_label":"Science Fiction","note":"A weary detective hunts synthetic humans through a rain-soaked city.","rank_in_genre":12},{"id":133,"title":"The Terminator","year":1984,"rating":8.1,"genre":"scifi","genre_label":"Science Fiction","note":"A machine is sent back to erase a woman before her son is born.","rank_in_genre":13},{"id":134,"title":"Aliens","year":1986,"rating":8.4,"genre":"scifi","genre_label":"Science Fiction","note":"Ripley returns to the derelict colony, this time with marines.","rank_in_genre":14},{"id":135,"title":"E.T. the Extra-Terrestrial","year":1982,"rating":7.8,"genre":"scifi","genre_label":"Science Fiction","note":"A stranded alien and a lonely boy build an unlikely friendship.","rank_in_genre":15},{"id":136,"title":"Minority Report","year":2002,"rating":7.6,"genre":"scifi","genre_label":"Science Fiction","note":"A cop who arrests future murderers becomes one of his own targets.","rank_in_genre":16},{"id":137,"title":"WALL-E","year":2008,"rating":8.4,"genre":"scifi","genre_label":"Science Fiction","note":"A lonely trash-compacting robot falls for a sleek scout from Earth's fleet.","rank_in_genre":17},{"id":138,"title":"District 9","year":2009,"rating":7.9,"genre":"scifi","genre_label":"Science Fiction","note":"A bureaucrat relocating alien refugees starts turning into one.","rank_in_genre":18},{"id":139,"title":"Star Trek","year":2009,"rating":7.9,"genre":"scifi","genre_label":"Science Fiction","note":"A young, reckless crew is thrown together for the Enterprise's first mission.","rank_in_genre":19},{"id":140,"title":"Ex Machina","year":2014,"rating":7.7,"genre":"scifi","genre_label":"Science Fiction","note":"A programmer tests just how human an AI's mind has become.","rank_in_genre":20},{"id":141,"title":"Edge of Tomorrow","year":2014,"rating":7.9,"genre":"scifi","genre_label":"Science Fiction","note":"A soldier relives the same alien invasion day until he gets it right.","rank_in_genre":21},{"id":142,"title":"Children of Men","year":2006,"rating":7.9,"genre":"scifi","genre_label":"Science Fiction","note":"In a world where no child has been born for 18 years, one miracle changes everything.","rank_in_genre":22},{"id":143,"title":"Dune","year":2021,"rating":8,"genre":"scifi","genre_label":"Science Fiction","note":"A duke's son is thrust into a desert planet's war over a priceless resource.","rank_in_genre":23},{"id":144,"title":"The Fifth Element","year":1997,"rating":7.6,"genre":"scifi","genre_label":"Science Fiction","note":"A cab driver becomes humanity's last hope against an ancient evil.","rank_in_genre":24},{"id":145,"title":"The Prestige","year":2006,"rating":8.5,"genre":"scifi","genre_label":"Science Fiction","note":"Two rival magicians escalate their feud into something far darker.","rank_in_genre":25},{"id":146,"title":"Metropolis","year":1927,"rating":8.3,"genre":"scifi","genre_label":"Science Fiction","note":"A city divided between elite planners and underground laborers reaches a breaking point.","rank_in_genre":26},{"id":147,"title":"A Clockwork Orange","year":1971,"rating":8.3,"genre":"scifi","genre_label":"Science Fiction","note":"A violent delinquent is subjected to a controversial behavioral experiment.","rank_in_genre":27},{"id":148,"title":"Close Encounters of the Third Kind","year":1977,"rating":7.6,"genre":"scifi","genre_label":"Science Fiction","note":"Strange sightings pull an ordinary man toward a first contact event.","rank_in_genre":28},{"id":149,"title":"Total Recall","year":1990,"rating":7.5,"genre":"scifi","genre_label":"Science Fiction","note":"A man's implanted Mars vacation memory turns out to be very real.","rank_in_genre":29},{"id":150,"title":"RoboCop","year":1987,"rating":7.6,"genre":"scifi","genre_label":"Science Fiction","note":"A slain officer is rebuilt as a cyborg enforcer for a crime-ridden city.","rank_in_genre":30},{"id":151,"title":"Twelve Monkeys","year":1995,"rating":8,"genre":"scifi","genre_label":"Science Fiction","note":"A time traveler is sent back to find the source of a civilization-ending virus.","rank_in_genre":31},{"id":152,"title":"Gattaca","year":1997,"rating":7.8,"genre":"scifi","genre_label":"Science Fiction","note":"A genetically imperfect man fakes his way toward a career among the engineered elite.","rank_in_genre":32},{"id":153,"title":"The Truman Show","year":1998,"rating":8.2,"genre":"scifi","genre_label":"Science Fiction","note":"A man slowly realizes his entire life has been a broadcast television show.","rank_in_genre":33},{"id":154,"title":"Dark City","year":1998,"rating":7.6,"genre":"scifi","genre_label":"Science Fiction","note":"A man wakes with no memory in a city that rebuilds itself every night.","rank_in_genre":34},{"id":155,"title":"Donnie Darko","year":2001,"rating":8,"genre":"scifi","genre_label":"Science Fiction","note":"A troubled teen is warned of the world's end by a menacing rabbit figure.","rank_in_genre":35},{"id":156,"title":"Moon","year":2009,"rating":7.8,"genre":"scifi","genre_label":"Science Fiction","note":"A lone lunar miner nearing the end of his contract uncovers an unsettling secret.","rank_in_genre":36},{"id":157,"title":"Avatar","year":2009,"rating":7.9,"genre":"scifi","genre_label":"Science Fiction","note":"A paraplegic marine embedded among an alien tribe questions which side he's on.","rank_in_genre":37},{"id":158,"title":"Looper","year":2012,"rating":7.4,"genre":"scifi","genre_label":"Science Fiction","note":"A hitman who kills targets sent from the future faces his own older self.","rank_in_genre":38},{"id":159,"title":"Gravity","year":2013,"rating":7.7,"genre":"scifi","genre_label":"Science Fiction","note":"Two astronauts fight to survive after debris destroys their shuttle.","rank_in_genre":39},{"id":160,"title":"Elysium","year":2013,"rating":6.6,"genre":"scifi","genre_label":"Science Fiction","note":"Earth's poor look up at a luxurious space station they're forbidden to reach.","rank_in_genre":40},{"id":161,"title":"Snowpiercer","year":2013,"rating":7.1,"genre":"scifi","genre_label":"Science Fiction","note":"The last of humanity survives aboard a train that never stops moving.","rank_in_genre":41},{"id":162,"title":"Guardians of the Galaxy","year":2014,"rating":8,"genre":"scifi","genre_label":"Science Fiction","note":"A ragtag crew of misfits is forced to save the galaxy nobody asked them to.","rank_in_genre":42},{"id":163,"title":"Ready Player One","year":2018,"rating":7.4,"genre":"scifi","genre_label":"Science Fiction","note":"A virtual reality treasure hunt determines who controls the world's favorite escape.","rank_in_genre":43},{"id":164,"title":"Annihilation","year":2018,"rating":6.8,"genre":"scifi","genre_label":"Science Fiction","note":"A team enters a mutating zone where nature itself no longer follows the rules.","rank_in_genre":44},{"id":165,"title":"Spider-Man: Into the Spider-Verse","year":2018,"rating":8.4,"genre":"scifi","genre_label":"Science Fiction","note":"A new Spider-Man meets alternate versions of himself from other dimensions.","rank_in_genre":45},{"id":166,"title":"Avengers: Endgame","year":2019,"rating":8.4,"genre":"scifi","genre_label":"Science Fiction","note":"The remaining Avengers attempt one last plan to undo a universal catastrophe.","rank_in_genre":46},{"id":167,"title":"Tenet","year":2020,"rating":7.3,"genre":"scifi","genre_label":"Science Fiction","note":"An agent learns to manipulate the flow of time itself to stop a hidden war.","rank_in_genre":47},{"id":168,"title":"Everything Everywhere All at Once","year":2022,"rating":7.8,"genre":"scifi","genre_label":"Science Fiction","note":"A laundromat owner discovers she must save the multiverse from collapse.","rank_in_genre":48},{"id":169,"title":"Independence Day","year":1996,"rating":7,"genre":"scifi","genre_label":"Science Fiction","note":"Humanity unites to fight back after alien ships appear over its biggest cities.","rank_in_genre":49},{"id":170,"title":"Men in Black","year":1997,"rating":7.3,"genre":"scifi","genre_label":"Science Fiction","note":"A secret agency polices the alien population quietly living on Earth.","rank_in_genre":50},{"id":171,"title":"Contact","year":1997,"rating":7.4,"genre":"scifi","genre_label":"Science Fiction","note":"A scientist follows a mysterious signal that may be humanity's first contact.","rank_in_genre":51},{"id":172,"title":"The Iron Giant","year":1999,"rating":8.1,"genre":"scifi","genre_label":"Science Fiction","note":"A boy befriends a giant robot that fell from the sky, unsure of its purpose.","rank_in_genre":52},{"id":173,"title":"A.I. Artificial Intelligence","year":2001,"rating":7.1,"genre":"scifi","genre_label":"Science Fiction","note":"A robotic child searches for a way to become real so his mother will love him.","rank_in_genre":53},{"id":174,"title":"War of the Worlds","year":2005,"rating":6.5,"genre":"scifi","genre_label":"Science Fiction","note":"A father tries to get his kids to safety as alien war machines level cities.","rank_in_genre":54},{"id":175,"title":"Pacific Rim","year":2013,"rating":7,"genre":"scifi","genre_label":"Science Fiction","note":"Giant robot pilots defend the coastlines against monsters rising from the sea.","rank_in_genre":55},{"id":176,"title":"Oblivion","year":2013,"rating":7,"genre":"scifi","genre_label":"Science Fiction","note":"A drone repairman on a ravaged Earth begins to question his own memories.","rank_in_genre":56},{"id":177,"title":"Cloud Atlas","year":2012,"rating":7.4,"genre":"scifi","genre_label":"Science Fiction","note":"Six interconnected stories span centuries, all echoing the same souls.","rank_in_genre":57},{"id":178,"title":"Chappie","year":2015,"rating":6.8,"genre":"scifi","genre_label":"Science Fiction","note":"A stolen police robot is given consciousness and raised by amateur criminals.","rank_in_genre":58},{"id":179,"title":"Alita: Battle Angel","year":2019,"rating":7.3,"genre":"scifi","genre_label":"Science Fiction","note":"A cyborg with no memory of her past is rebuilt and finds she's a born fighter.","rank_in_genre":59},{"id":180,"title":"The Matrix Revolutions","year":2003,"rating":6.4,"genre":"scifi","genre_label":"Science Fiction","note":"The war between humans and machines reaches its final confrontation.","rank_in_genre":60},{"id":181,"title":"The Shawshank Redemption","year":1994,"rating":9.3,"genre":"drama","genre_label":"Drama","note":"Two decades in Shawshank, patience carved into stone.","rank_in_genre":1},{"id":182,"title":"The Godfather","year":1972,"rating":9.2,"genre":"drama","genre_label":"Drama","note":"A crime family's quiet son inherits an empire of favors.","rank_in_genre":2},{"id":183,"title":"The Godfather Part II","year":1974,"rating":9,"genre":"drama","genre_label":"Drama","note":"Two timelines — one rise, one reign — braided together.","rank_in_genre":3},{"id":184,"title":"12 Angry Men","year":1957,"rating":9,"genre":"drama","genre_label":"Drama","note":"Eleven guilty votes, one holdout, and a very hot jury room.","rank_in_genre":4},{"id":185,"title":"Schindler's List","year":1993,"rating":9,"genre":"drama","genre_label":"Drama","note":"A list that becomes the only thing standing between life and death.","rank_in_genre":5},{"id":186,"title":"Forrest Gump","year":1994,"rating":8.8,"genre":"drama","genre_label":"Drama","note":"A simple man walks through three decades of American history.","rank_in_genre":6},{"id":187,"title":"Fight Club","year":1999,"rating":8.8,"genre":"drama","genre_label":"Drama","note":"An insomniac, a soap salesman, and a club with one rule.","rank_in_genre":7},{"id":188,"title":"One Flew Over the Cuckoo's Nest","year":1975,"rating":8.7,"genre":"drama","genre_label":"Drama","note":"A new patient tests the walls of a psychiatric ward.","rank_in_genre":8},{"id":189,"title":"Goodfellas","year":1990,"rating":8.7,"genre":"drama","genre_label":"Drama","note":"Three decades inside the mob, told by the man who lived it.","rank_in_genre":9},{"id":190,"title":"City of God","year":2002,"rating":8.6,"genre":"drama","genre_label":"Drama","note":"Two boys, one camera, one slum — and very different fates.","rank_in_genre":10},{"id":191,"title":"Pulp Fiction","year":1994,"rating":8.9,"genre":"drama","genre_label":"Drama","note":"Hitmen, a boxer, and a diner heist, told out of order and back again.","rank_in_genre":11},{"id":192,"title":"The Silence of the Lambs","year":1991,"rating":8.6,"genre":"drama","genre_label":"Drama","note":"A trainee FBI agent trades information with an imprisoned killer.","rank_in_genre":12},{"id":193,"title":"Se7en","year":1995,"rating":8.6,"genre":"drama","genre_label":"Drama","note":"Two detectives chase a killer staging murders around the seven sins.","rank_in_genre":13},{"id":194,"title":"The Green Mile","year":1999,"rating":8.6,"genre":"drama","genre_label":"Drama","note":"A death row guard meets an inmate with an impossible gift.","rank_in_genre":14},{"id":195,"title":"Grave of the Fireflies","year":1988,"rating":8.5,"genre":"drama","genre_label":"Drama","note":"A brother and sister struggle to survive the final months of the war.","rank_in_genre":15},{"id":196,"title":"The Pianist","year":2002,"rating":8.5,"genre":"drama","genre_label":"Drama","note":"A Jewish pianist hides in the ruins of Warsaw during the occupation.","rank_in_genre":16},{"id":197,"title":"Whiplash","year":2014,"rating":8.5,"genre":"drama","genre_label":"Drama","note":"A drumming student pushes himself to the edge under a brutal instructor.","rank_in_genre":17},{"id":198,"title":"The Departed","year":2006,"rating":8.5,"genre":"drama","genre_label":"Drama","note":"A cop and a criminal each go undercover in the other's world.","rank_in_genre":18},{"id":199,"title":"Parasite","year":2019,"rating":8.5,"genre":"drama","genre_label":"Drama","note":"A poor family cons its way into a wealthy household, and it spirals.","rank_in_genre":19},{"id":200,"title":"Saving Private Ryan","year":1998,"rating":8.6,"genre":"drama","genre_label":"Drama","note":"A squad is sent behind enemy lines to bring one soldier home.","rank_in_genre":20},{"id":201,"title":"American History X","year":1998,"rating":8.5,"genre":"drama","genre_label":"Drama","note":"A reformed neo-Nazi tries to stop his younger brother from following his old path.","rank_in_genre":21},{"id":202,"title":"Joker","year":2019,"rating":8.4,"genre":"drama","genre_label":"Drama","note":"A failed comedian's isolation curdles into something the city can't ignore.","rank_in_genre":22},{"id":203,"title":"American Beauty","year":1999,"rating":8.3,"genre":"drama","genre_label":"Drama","note":"A suburban father's midlife unraveling upends everyone around him.","rank_in_genre":23},{"id":204,"title":"A Beautiful Mind","year":2001,"rating":8.2,"genre":"drama","genre_label":"Drama","note":"A brilliant mathematician's genius and delusions become impossible to separate.","rank_in_genre":24},{"id":205,"title":"Spirited Away","year":2001,"rating":8.6,"genre":"drama","genre_label":"Drama","note":"A girl gets trapped in a spirit world and must work to free her parents.","rank_in_genre":25},{"id":206,"title":"There Will Be Blood","year":2007,"rating":8.2,"genre":"drama","genre_label":"Drama","note":"A ruthless oilman's ambition consumes everyone and everything around him.","rank_in_genre":26},{"id":207,"title":"No Country for Old Men","year":2007,"rating":8.2,"genre":"drama","genre_label":"Drama","note":"A hunter who finds drug money becomes prey for a relentless killer.","rank_in_genre":27},{"id":208,"title":"The Social Network","year":2010,"rating":7.7,"genre":"drama","genre_label":"Drama","note":"A dorm-room idea grows into Facebook, and the friendships behind it don't survive.","rank_in_genre":28},{"id":209,"title":"Good Will Hunting","year":1997,"rating":8.3,"genre":"drama","genre_label":"Drama","note":"A janitor's hidden genius is discovered, but his past is what really holds him back.","rank_in_genre":29},{"id":210,"title":"Gone Girl","year":2014,"rating":8.1,"genre":"drama","genre_label":"Drama","note":"A husband becomes the prime suspect when his wife vanishes on their anniversary.","rank_in_genre":30},{"id":211,"title":"Room","year":2015,"rating":8.1,"genre":"drama","genre_label":"Drama","note":"A mother and son held captive for years finally find a way out.","rank_in_genre":31},{"id":212,"title":"Manchester by the Sea","year":2016,"rating":7.8,"genre":"drama","genre_label":"Drama","note":"A man returns to his hometown and confronts a tragedy he can't outrun.","rank_in_genre":32},{"id":213,"title":"Moonlight","year":2016,"rating":7.4,"genre":"drama","genre_label":"Drama","note":"A young man's identity is shaped across three chapters of his life in Miami.","rank_in_genre":33},{"id":214,"title":"Requiem for a Dream","year":2000,"rating":8.3,"genre":"drama","genre_label":"Drama","note":"Four intertwined lives spiral downward chasing very different addictions.","rank_in_genre":34},{"id":215,"title":"Memento","year":2000,"rating":8.4,"genre":"drama","genre_label":"Drama","note":"A man with no short-term memory hunts his wife's killer using notes and tattoos.","rank_in_genre":35},{"id":216,"title":"Rain Man","year":1988,"rating":8,"genre":"drama","genre_label":"Drama","note":"A self-absorbed man discovers the autistic brother he never knew he had.","rank_in_genre":36},{"id":217,"title":"Dead Poets Society","year":1989,"rating":8.1,"genre":"drama","genre_label":"Drama","note":"An unconventional teacher pushes his students to seize their own lives.","rank_in_genre":37},{"id":218,"title":"The Elephant Man","year":1980,"rating":8.2,"genre":"drama","genre_label":"Drama","note":"A severely disfigured man is finally treated with dignity by a compassionate doctor.","rank_in_genre":38},{"id":219,"title":"Amadeus","year":1984,"rating":8.4,"genre":"drama","genre_label":"Drama","note":"A rival composer's jealousy of Mozart's genius curdles into obsession.","rank_in_genre":39},{"id":220,"title":"Chinatown","year":1974,"rating":8.2,"genre":"drama","genre_label":"Drama","note":"A private investigator uncovers a conspiracy far bigger than his original case.","rank_in_genre":40},{"id":221,"title":"Apocalypse Now","year":1979,"rating":8.4,"genre":"drama","genre_label":"Drama","note":"A soldier travels upriver into Cambodia on a mission that unravels his sanity.","rank_in_genre":41},{"id":222,"title":"Taxi Driver","year":1976,"rating":8.2,"genre":"drama","genre_label":"Drama","note":"A lonely, alienated cabbie's grip on reality slips as violence builds inside him.","rank_in_genre":42},{"id":223,"title":"Raging Bull","year":1980,"rating":8.2,"genre":"drama","genre_label":"Drama","note":"A boxer's fury in the ring destroys everything he has outside of it.","rank_in_genre":43},{"id":224,"title":"The Sixth Sense","year":1999,"rating":8.1,"genre":"drama","genre_label":"Drama","note":"A troubled boy who sees the dead finds an unlikely ally in his new psychologist.","rank_in_genre":44},{"id":225,"title":"American Gangster","year":2007,"rating":7.8,"genre":"drama","genre_label":"Drama","note":"A Harlem drug lord's rise draws the attention of one determined detective.","rank_in_genre":45},{"id":226,"title":"12 Years a Slave","year":2013,"rating":8.1,"genre":"drama","genre_label":"Drama","note":"A free man is kidnapped and sold into slavery in the pre-Civil War South.","rank_in_genre":46},{"id":227,"title":"The Wolf of Wall Street","year":2013,"rating":8.2,"genre":"drama","genre_label":"Drama","note":"A stockbroker's excess and fraud spiral completely out of control.","rank_in_genre":47},{"id":228,"title":"Nightcrawler","year":2014,"rating":7.8,"genre":"drama","genre_label":"Drama","note":"A hungry freelance cameraman will do almost anything for the perfect shot.","rank_in_genre":48},{"id":229,"title":"The Grand Budapest Hotel","year":2014,"rating":8.1,"genre":"drama","genre_label":"Drama","note":"A legendary concierge and his protégé get tangled in a stolen painting and a will.","rank_in_genre":49},{"id":230,"title":"Boyhood","year":2014,"rating":7.9,"genre":"drama","genre_label":"Drama","note":"A boy's life is filmed over twelve real years, growing up on screen.","rank_in_genre":50},{"id":231,"title":"Spotlight","year":2015,"rating":8.1,"genre":"drama","genre_label":"Drama","note":"A team of journalists uncovers a decades-long cover-up within the Church.","rank_in_genre":51},{"id":232,"title":"The Revenant","year":2015,"rating":8,"genre":"drama","genre_label":"Drama","note":"A frontiersman left for dead claws his way back for revenge.","rank_in_genre":52},{"id":233,"title":"Hacksaw Ridge","year":2016,"rating":8.1,"genre":"drama","genre_label":"Drama","note":"A combat medic refuses to carry a weapon into one of the war's bloodiest battles.","rank_in_genre":53},{"id":234,"title":"Get Out","year":2017,"rating":7.7,"genre":"drama","genre_label":"Drama","note":"A weekend meeting his girlfriend's parents turns into something far more sinister.","rank_in_genre":54},{"id":235,"title":"Three Billboards Outside Ebbing, Missouri","year":2017,"rating":8.1,"genre":"drama","genre_label":"Drama","note":"A grieving mother's billboards ignite a war with the local police.","rank_in_genre":55},{"id":236,"title":"Bohemian Rhapsody","year":2018,"rating":7.9,"genre":"drama","genre_label":"Drama","note":"A band's unlikely rise traces the life of its singular frontman.","rank_in_genre":56},{"id":237,"title":"Marriage Story","year":2019,"rating":7.9,"genre":"drama","genre_label":"Drama","note":"A couple's divorce turns amicable intentions into an all-out legal fight.","rank_in_genre":57},{"id":238,"title":"The Irishman","year":2019,"rating":7.8,"genre":"drama","genre_label":"Drama","note":"An aging hitman looks back on decades inside the mob and its politics.","rank_in_genre":58},{"id":239,"title":"1917","year":2019,"rating":8.2,"genre":"drama","genre_label":"Drama","note":"Two soldiers race across enemy lines to deliver a message that could save thousands.","rank_in_genre":59},{"id":240,"title":"Sound of Metal","year":2019,"rating":7.7,"genre":"drama","genre_label":"Drama","note":"A drummer's sudden hearing loss forces him to reimagine his entire identity.","rank_in_genre":60}];
/**
 * Best Movies API Client
 */

// CSRF protection (double-submit cookie): the server sets a readable
// `csrf_token` cookie on every response. Any state-changing request (POST/
// DELETE) must echo that value back in the X-CSRF-Token header, proving the
// request was made by same-origin JS rather than a cross-site form/script.
function getCsrfToken() {
  const match = document.cookie.match(/(?:^|;\s*)csrf_token=([^;]+)/);
  return match ? decodeURIComponent(match[1]) : "";
}

function withCsrfHeaders(extra) {
  return Object.assign({ "X-CSRF-Token": getCsrfToken() }, extra || {});
}

const API = {
  // Auth endpoints
  async getMe() {
    try {
      const res = await fetch('/api/auth/me', { credentials: 'same-origin' });
      if (!res.ok) return { user: null };
      return await res.json();
    } catch (e) {
      return { user: null };
    }
  },

  async requestEmailOtp(email) {
    const res = await fetch('/api/auth/email/request-otp', {
      method: 'POST',
      headers: withCsrfHeaders({ 'Content-Type': 'application/json' }),
      credentials: 'same-origin',
      body: JSON.stringify({ email })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to request code');
    return data;
  },

  async verifyEmailOtp(email, code) {
    const res = await fetch('/api/auth/email/verify-otp', {
      method: 'POST',
      headers: withCsrfHeaders({ 'Content-Type': 'application/json' }),
      credentials: 'same-origin',
      body: JSON.stringify({ email, code })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Verification failed');
    return data;
  },

  async logout() {
    const res = await fetch('/api/auth/logout', {
      method: 'POST',
      headers: withCsrfHeaders(),
      credentials: 'same-origin'
    });
    return await res.json();
  },

  // Movie endpoints
  async getAllMovies() {
    const res = await fetch('/api/movies');
    if (!res.ok) throw new Error('Failed to load movies');
    return await res.json();
  },

  async getMoviesByGenre(genre) {
    const res = await fetch(`/api/movies/genre/${encodeURIComponent(genre)}`);
    if (!res.ok) throw new Error('Failed to load genre movies');
    return await res.json();
  },

  async searchMovies(query) {
    const res = await fetch(`/api/movies/search?q=${encodeURIComponent(query)}`);
    if (!res.ok) throw new Error('Search failed');
    return await res.json();
  },

  // Watchlist endpoints
  async getWatchlist() {
    const res = await fetch('/api/watchlist', { credentials: 'same-origin' });
    if (!res.ok) return { watchlist: [], keys: [] };
    return await res.json();
  },

  async addToWatchlist(movie) {
    const res = await fetch('/api/watchlist', {
      method: 'POST',
      headers: withCsrfHeaders({ 'Content-Type': 'application/json' }),
      credentials: 'same-origin',
      body: JSON.stringify({
        movieId: movie.id,
        title: movie.title,
        year: movie.year,
        genre: movie.genre
      })
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to add to watchlist');
    return data;
  },

  async removeFromWatchlist(movie) {
    const res = await fetch(`/api/watchlist/by-title?title=${encodeURIComponent(movie.title)}&year=${movie.year}`, {
      method: 'DELETE',
      headers: withCsrfHeaders(),
      credentials: 'same-origin'
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to remove from watchlist');
    return data;
  },

  async syncWatchlist(items) {
    const res = await fetch('/api/watchlist/sync', {
      method: 'POST',
      headers: withCsrfHeaders({ 'Content-Type': 'application/json' }),
      credentials: 'same-origin',
      body: JSON.stringify({ items })
    });
    if (!res.ok) return null;
    return await res.json();
  }
};

window.API = API;

/**
 * Poster Resolver
 * ----------------
 * Every one of the 240 movies gets a real poster, resolved lazily (only
 * when its card scrolls near the viewport) via the free, keyless iTunes
 * Search API, cached in localStorage so repeat visits and repeat cards
 * for the same film (a few titles appear in more than one genre) don't
 * re-fetch. Never blocks page load, never leaves a broken-image icon —
 * every image starts on the local fallback artwork and only swaps to a
 * real poster once one is confirmed to load.
 */
(function() {
  const CACHE_KEY = "bestmovies_poster_cache_v1";
  const FALLBACK = "/assets/fallback-poster.svg";
  const MAX_CACHE_ENTRIES = 600;

  let cache = {};
  try {
    cache = JSON.parse(localStorage.getItem(CACHE_KEY) || "{}");
  } catch (e) {
    cache = {};
  }

  function cacheKey(title, year) {
    return `${String(title).toLowerCase()}__${year}`;
  }

  function persistCache() {
    try {
      const keys = Object.keys(cache);
      if (keys.length > MAX_CACHE_ENTRIES) {
        keys.slice(0, keys.length - MAX_CACHE_ENTRIES).forEach((k) => delete cache[k]);
      }
      localStorage.setItem(CACHE_KEY, JSON.stringify(cache));
    } catch (e) {
      /* localStorage unavailable (private mode / quota) — cache just won't persist */
    }
  }

  // In-flight requests, de-duplicated so the same film isn't looked up twice
  // in parallel (it can appear in more than one genre list).
  const inFlight = new Map();

  async function fetchPosterUrl(title, year) {
    const key = cacheKey(title, year);
    if (Object.prototype.hasOwnProperty.call(cache, key)) return cache[key];
    if (inFlight.has(key)) return inFlight.get(key);

    const promise = (async () => {
      try {
        const term = encodeURIComponent(`${title} ${year}`);
        const res = await fetch(
          `https://itunes.apple.com/search?term=${term}&media=movie&entity=movie&limit=5`
        );
        if (!res.ok) throw new Error("iTunes lookup failed");
        const data = await res.json();
        const results = Array.isArray(data.results) ? data.results : [];
        const yearMatch = results.find((r) => {
          const ry = r.releaseDate ? new Date(r.releaseDate).getFullYear() : null;
          return ry === Number(year);
        });
        const best = yearMatch || results[0] || null;
        let url = null;
        if (best && best.artworkUrl100) {
          // Request a larger crop than the default 100x100 thumbnail.
          url = best.artworkUrl100.replace(/\d+x\d+bb\.(jpg|png)/, "600x600bb.$1");
        }
        cache[key] = url; // cache a confirmed "no poster found" (null) too
        persistCache();
        return url;
      } catch (e) {
        // Network hiccup: don't poison the cache with a permanent failure —
        // allow a retry on the next render.
        return null;
      } finally {
        inFlight.delete(key);
      }
    })();

    inFlight.set(key, promise);
    return promise;
  }

  function markSettled(img) {
    img.classList.remove("poster-loading");
    img.classList.add("poster-settled");
  }

  function applyFallback(img) {
    img.src = FALLBACK;
    markSettled(img);
  }

  async function resolveImg(img) {
    if (img.dataset.resolved === "1") return;
    img.dataset.resolved = "1";
    const { title, year } = img.dataset;
    if (!title || !year) return applyFallback(img);

    const url = await fetchPosterUrl(title, year);
    if (!url) return applyFallback(img);

    // Preload off-DOM so the swap only happens once the image is decoded —
    // avoids a flash of a half-loaded image and keeps a failed fetch from
    // ever showing a broken-image icon.
    const preloader = new Image();
    preloader.onload = () => {
      img.src = url;
      markSettled(img);
    };
    preloader.onerror = () => applyFallback(img);
    preloader.src = url;
  }

  let observer = null;
  function getObserver() {
    if (observer || !("IntersectionObserver" in window)) return observer;
    observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            resolveImg(entry.target);
            observer.unobserve(entry.target);
          }
        });
      },
      { rootMargin: "250px 0px" }
    );
    return observer;
  }

  function observeWithin(root) {
    const scope = root || document;
    const imgs = scope.querySelectorAll('.poster-img[data-title]:not([data-resolved="1"])');
    const io = getObserver();
    imgs.forEach((img) => (io ? io.observe(img) : resolveImg(img)));
  }

  // Last-resort safety net: if a poster image fails to load for any reason
  // not already covered above (e.g. the resolved CDN URL later 404s),
  // swap to the local fallback instead of showing a broken-image icon.
  // 'error' events don't bubble, so this listener must use the capture phase.
  document.addEventListener(
    "error",
    (e) => {
      const t = e.target;
      if (t && t.tagName === "IMG" && t.classList && t.classList.contains("poster-img")) {
        if (t.dataset.fallbackApplied === "1") return;
        t.dataset.fallbackApplied = "1";
        t.src = FALLBACK;
        markSettled(t);
      }
    },
    true
  );

  window.PosterResolver = { fetchPosterUrl, observeWithin, FALLBACK };
})();

/**
 * Best Movies Authentication Controller
 */
(function() {
  let currentUser = null;
  let pendingEmail = '';

  const accountCorner = document.getElementById("account-corner");
  const accountBtn = document.getElementById("account-btn");
  const accountDropdown = document.getElementById("account-dropdown");
  const accountLabel = document.getElementById("account-label");
  const accountAvatar = document.getElementById("account-avatar");
  const accountDropdownEmail = document.getElementById("account-dropdown-email");
  const signoutBtn = document.getElementById("signout-btn");

  const authOverlay = document.getElementById("auth-overlay");
  const authClose = document.getElementById("auth-close");
  const googleBtn = document.getElementById("google-btn");

  const emailStep1 = document.getElementById("email-step-1");
  const emailStep2 = document.getElementById("email-step-2");
  const emailForm1 = document.getElementById("email-form-1");
  const emailForm2 = document.getElementById("email-form-2");
  const emailInput = document.getElementById("email-input");
  const otpInput = document.getElementById("otp-input");
  const otpEmailDisplay = document.getElementById("otp-email-display");
  const backToEmailBtn = document.getElementById("back-to-email-btn");
  const authErrorMsg = document.getElementById("auth-error-msg");

  const PERSON_ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-7 8-7s8 3 8 7"/></svg>';

  function openAuthModal() {
    authOverlay.hidden = false;
    document.body.style.overflow = "hidden";
    resetAuthSteps();
    setTimeout(() => emailInput.focus(), 60);
  }

  function closeAuthModal() {
    authOverlay.hidden = true;
    document.body.style.overflow = "";
    resetAuthSteps();
  }

  function resetAuthSteps() {
    if (emailStep1) emailStep1.hidden = false;
    if (emailStep2) emailStep2.hidden = true;
    if (authErrorMsg) {
      authErrorMsg.textContent = '';
      authErrorMsg.hidden = true;
    }
    if (emailForm1) emailForm1.reset();
    if (emailForm2) emailForm2.reset();
    pendingEmail = '';
  }

  function setAuthError(msg) {
    if (authErrorMsg) {
      authErrorMsg.textContent = msg;
      authErrorMsg.hidden = !msg;
    }
  }

  function updateAccountUI() {
    if (currentUser) {
      if (currentUser.avatar_url) {
        accountAvatar.innerHTML = `<img src="${currentUser.avatar_url}" alt="${currentUser.name || currentUser.email}" style="width:100%;height:100%;border-radius:50%;object-fit:cover;"/>`;
        accountAvatar.classList.remove("has-initial");
      } else {
        const initial = (currentUser.name || currentUser.email || 'U')[0].toUpperCase();
        accountAvatar.textContent = initial;
        accountAvatar.classList.add("has-initial");
      }
      const displayName = currentUser.name || currentUser.email.split("@")[0];
      accountLabel.textContent = displayName;
      accountDropdownEmail.textContent = currentUser.email;
    } else {
      accountAvatar.innerHTML = PERSON_ICON;
      accountAvatar.classList.remove("has-initial");
      accountLabel.textContent = "Sign In";
      accountDropdownEmail.textContent = "";
    }
  }

  async function checkSession() {
    try {
      const data = await window.API.getMe();
      currentUser = data.user;
      updateAccountUI();
      if (currentUser && window.MovieApp && window.MovieApp.onLoginSuccess) {
        window.MovieApp.onLoginSuccess();
      }
    } catch (e) {
      console.error('Session check failed', e);
    }
  }

  // Handle URL parameters for OAuth callbacks
  function checkUrlAuthParams() {
    const params = new URLSearchParams(window.location.search);
    if (params.get('login') === 'google_success') {
      window.showToast("Signed in with Google successfully!");
      window.history.replaceState({}, document.title, window.location.pathname);
    } else if (params.get('auth_error')) {
      const err = params.get('auth_error');
      if (err === 'cancelled') {
        window.showToast("Google sign-in was cancelled.");
      } else if (err === 'google_not_configured') {
        window.showToast("Google OAuth is not configured in .env. Use email sign-in or add credentials.");
      } else {
        window.showToast("Authentication failed. Please try again.");
      }
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }

  // Google OAuth button
  googleBtn.addEventListener("click", () => {
    // Navigate directly to backend Google OAuth initiation endpoint
    window.location.href = '/api/auth/google';
  });

  // Step 1: Request OTP
  if (emailForm1) {
    emailForm1.addEventListener("submit", async (e) => {
      e.preventDefault();
      const email = emailInput.value.trim().toLowerCase();
      if (!email || !emailInput.checkValidity()) {
        emailInput.reportValidity();
        return;
      }

      setAuthError('');
      const submitBtn = emailForm1.querySelector('button[type="submit"]');
      const originalText = submitBtn.textContent;
      submitBtn.disabled = true;
      submitBtn.textContent = 'Sending code...';

      try {
        const res = await window.API.requestEmailOtp(email);
        pendingEmail = email;
        emailStep1.hidden = true;
        emailStep2.hidden = false;
        otpEmailDisplay.textContent = email;
        if (res.isDevConsole) {
          window.showToast("Local Dev Mode: 6-digit code logged in server console!");
        } else {
          window.showToast("Verification code sent to your email!");
        }
        setTimeout(() => otpInput.focus(), 60);
      } catch (err) {
        setAuthError(err.message || 'Failed to send code.');
      } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = originalText;
      }
    });
  }

  // Step 2: Verify OTP
  if (emailForm2) {
    emailForm2.addEventListener("submit", async (e) => {
      e.preventDefault();
      const code = otpInput.value.trim();
      if (!code || code.length !== 6) {
        setAuthError('Please enter the 6-digit code.');
        return;
      }

      setAuthError('');
      const submitBtn = emailForm2.querySelector('button[type="submit"]');
      const originalText = submitBtn.textContent;
      submitBtn.disabled = true;
      submitBtn.textContent = 'Verifying...';

      try {
        const res = await window.API.verifyEmailOtp(pendingEmail, code);
        currentUser = res.user;
        updateAccountUI();
        closeAuthModal();
        window.showToast(`Signed in as ${currentUser.email}`);

        // Sync local offline watchlist with server
        if (window.MovieApp && window.MovieApp.onLoginSuccess) {
          await window.MovieApp.onLoginSuccess();
        }
      } catch (err) {
        setAuthError(err.message || 'Invalid or expired code.');
      } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = originalText;
      }
    });
  }

  if (backToEmailBtn) {
    backToEmailBtn.addEventListener("click", () => {
      emailStep2.hidden = true;
      emailStep1.hidden = false;
      setAuthError('');
      emailInput.focus();
    });
  }

  // Account dropdown toggle
  accountBtn.addEventListener("click", () => {
    if (currentUser) {
      const willShow = accountDropdown.hidden;
      accountDropdown.hidden = !willShow;
      accountBtn.setAttribute("aria-expanded", String(willShow));
    } else {
      openAuthModal();
    }
  });

  document.addEventListener("click", (e) => {
    if (!accountDropdown.hidden && !accountCorner.contains(e.target)) {
      accountDropdown.hidden = true;
      accountBtn.setAttribute("aria-expanded", "false");
    }
  });

  // Sign out
  signoutBtn.addEventListener("click", async () => {
    accountDropdown.hidden = true;
    accountBtn.setAttribute("aria-expanded", "false");
    try {
      await window.API.logout();
      currentUser = null;
      updateAccountUI();
      if (window.MovieApp && window.MovieApp.onLogoutSuccess) {
        window.MovieApp.onLogoutSuccess();
      }
      window.showToast("Signed out successfully");
    } catch (err) {
      console.error('Logout error', err);
    }
  });

  // Modal close handlers
  authClose.addEventListener("click", closeAuthModal);
  authOverlay.addEventListener("click", (e) => {
    if (e.target === authOverlay) closeAuthModal();
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      if (!authOverlay.hidden) closeAuthModal();
      if (!accountDropdown.hidden) {
        accountDropdown.hidden = true;
        accountBtn.setAttribute("aria-expanded", "false");
      }
    }
  });

  window.Auth = {
    init() {
      checkUrlAuthParams();
      checkSession();
    },
    getCurrentUser() {
      return currentUser;
    },
    openModal: openAuthModal,
    closeModal: closeAuthModal
  };
})();

/**
 * Best Movies — Client Application
 * Strictly preserves 100% of the 240 original movies and all interactive features.
 */
(function() {
  // Elements
  const buttons = document.querySelectorAll(".genre-btn");
  const resultsTitle = document.getElementById("results-title");
  const resultsCount = document.getElementById("results-count");
  const resultsLabel = document.getElementById("results-label");
  const resultsBody = document.getElementById("results-body");
  const resultsSection = document.getElementById("results");
  const sortControl = document.getElementById("sort-control");
  const wlCountEl = document.getElementById("wl-count");
  const miniWlCountEl = document.getElementById("mini-wl-count");
  const toastEl = document.getElementById("toast");
  const toastTextEl = document.getElementById("toast-text");

  const searchInput = document.getElementById("search-input");
  const searchClearBtn = document.getElementById("search-clear-btn");
  const surpriseBtn = document.getElementById("surprise-btn");

  const miniNav = document.getElementById("mini-nav");
  const miniGenres = document.getElementById("mini-genres");
  const miniTitle = document.getElementById("mini-title");
  const miniWatchlistBtn = document.getElementById("mini-watchlist-btn");

  // Cinematic Modal Elements
  const movieModal = document.getElementById("movie-modal");
  const modalBackdrop = document.getElementById("modal-backdrop");
  const modalCloseBtn = document.getElementById("movie-modal-close");
  const modalPoster = document.getElementById("modal-poster");
  const modalTitle = document.getElementById("modal-title");
  const modalYear = document.getElementById("modal-year");
  const modalRating = document.getElementById("modal-rating");
  const modalGenre = document.getElementById("modal-genre");
  const modalNote = document.getElementById("modal-note");
  const modalWatchBtn = document.getElementById("modal-watch-btn");
  const modalTrailerBtn = document.getElementById("modal-trailer-btn");
  const modalListBtn = document.getElementById("modal-list-btn");

  // State
  let DATA = {};
  let ALL_FILMS = [];
  let watchlist = new Set();       // set of filmKeys ("Title__Year")
  let currentSort = "rating";      // "rating" | "year" | "title"
  let currentView = { type: "none", key: null };
  let searchDebounceTimer = null;
  let activeModalFilm = null;

  function filmKey(film) {
    return `${film.title}__${film.year}`;
  }

  // --- Watchlist Persistence (Cloud + Local Fallback) ---
  async function loadWatchlist() {
    const user = window.Auth ? window.Auth.getCurrentUser() : null;
    if (user) {
      try {
        const data = await window.API.getWatchlist();
        if (data && Array.isArray(data.keys)) {
          watchlist = new Set(data.keys);
        } else {
          watchlist = new Set();
        }
      } catch (e) {
        loadFromLocalStorage();
      }
    } else {
      loadFromLocalStorage();
    }
    updateWatchlistCount();
    if (currentView.type === "genre") render(currentView.key, { silent: true });
    else if (currentView.type === "watchlist") renderWatchlist({ silent: true });
    else if (currentView.type === "search") runSearch(currentView.key, { silent: true });
  }

  function loadFromLocalStorage() {
    try {
      const saved = JSON.parse(localStorage.getItem("bestmovies_watchlist") || "[]");
      watchlist = Array.isArray(saved) ? new Set(saved) : new Set();
    } catch (e) {
      watchlist = new Set();
    }
  }

  function saveToLocalStorage() {
    try {
      localStorage.setItem("bestmovies_watchlist", JSON.stringify([...watchlist]));
    } catch (e) {}
  }

  function updateWatchlistCount() {
    const n = watchlist.size;
    if (wlCountEl) wlCountEl.textContent = n;
    if (miniWlCountEl) miniWlCountEl.textContent = n ? `My List (${n})` : "My List";
  }

  let toastTimer = null;
  function showToast(message) {
    if (!toastEl || !toastTextEl) return;
    toastTextEl.textContent = message;
    toastEl.classList.add("visible");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove("visible"), 2200);
  }
  window.showToast = showToast;

  async function toggleWatchlist(key, film, btnEl) {
    const isSaved = watchlist.has(key);
    const user = window.Auth ? window.Auth.getCurrentUser() : null;

    if (isSaved) {
      watchlist.delete(key);
      if (user) {
        try {
          await window.API.removeFromWatchlist(film);
        } catch (e) {
          console.warn('Backend sync failed, updated locally', e);
        }
      } else {
        saveToLocalStorage();
      }
    } else {
      watchlist.add(key);
      if (user) {
        try {
          await window.API.addToWatchlist(film);
        } catch (e) {
          console.warn('Backend sync failed, updated locally', e);
        }
      } else {
        saveToLocalStorage();
      }
    }

    updateWatchlistCount();

    // Update heart icons across the UI
    document.querySelectorAll(`.heart-btn[data-key="${CSS.escape(key)}"]`).forEach(btn => {
      btn.classList.toggle("active", !isSaved);
      btn.setAttribute("aria-pressed", String(!isSaved));
      btn.setAttribute("aria-label", !isSaved ? "Remove from My List" : "Add to My List");
    });

    if (activeModalFilm && filmKey(activeModalFilm) === key) {
      updateModalListButton(!isSaved);
    }

    if (btnEl) {
      btnEl.classList.remove("pulse");
      void btnEl.offsetWidth;
      btnEl.classList.add("pulse");
    }

    showToast(!isSaved ? `Added "${film.title}" to My List` : `Removed "${film.title}" from My List`);

    if (currentView.type === "watchlist") {
      renderWatchlist({ silent: true });
    }
  }

  // Links
  function imdbSearchUrl(title, year) {
    return `https://www.imdb.com/find/?q=${encodeURIComponent(title + " " + year)}&s=tt&ttype=ft`;
  }
  function trailerSearchUrl(title, year) {
    return `https://www.youtube.com/results?search_query=${encodeURIComponent(title + " " + year + " official trailer")}`;
  }
  function watchSearchUrl(title) {
    return `https://www.justwatch.com/us/search?q=${encodeURIComponent(title)}`;
  }

  // Card Builder
  function escapeAttr(str) {
    return String(str).replace(/[&<>"']/g, (c) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
    }[c]));
  }

  function buildCard(film, rank, delay) {
    const imdb = imdbSearchUrl(film.title, film.year);
    const trailer = trailerSearchUrl(film.title, film.year);
    const watch = watchSearchUrl(film.title);
    const key = filmKey(film);
    const isSaved = watchlist.has(key);
    const safeTitle = escapeAttr(film.title);
    const posterFallback = (window.PosterResolver && window.PosterResolver.FALLBACK) || "/assets/fallback-poster.svg";

    return `
      <article class="ticket" style="animation-delay:${delay}s" data-key="${key}">
        <div class="poster-container" data-action="open-detail">
          <img class="poster-img poster-loading" src="${posterFallback}" data-title="${safeTitle}" data-year="${film.year}" alt="${safeTitle} (${film.year}) Poster" loading="lazy"/>
          <span class="rank-badge">${rank}</span>
          <div class="poster-overlay">
            <span class="overlay-cue">View Details</span>
          </div>
        </div>
        <button class="heart-btn${isSaved ? " active" : ""}" data-key="${key}" type="button" aria-pressed="${isSaved}" aria-label="${isSaved ? "Remove from My List" : "Add to My List"}">
          <svg viewBox="0 0 24 24"><path d="M12 21s-7.5-4.6-10-9.2C.5 8.4 2.3 5 6 5c2.1 0 3.6 1.2 4.5 2.6C11.4 6.2 12.9 5 15 5c3.7 0 5.5 3.4 4 6.8C19.5 16.4 12 21 12 21z"/></svg>
        </button>
        <div class="body">
          <div class="top-row">
            <h3 class="film-card-title" data-action="open-detail" title="View details for ${film.title}">${film.title}</h3>
            <span class="year">${film.year}</span>
          </div>
          <span class="rating">
            <svg viewBox="0 0 24 24"><path d="M12 2l2.9 6.6 7.1.6-5.4 4.7 1.6 7-6.2-3.8-6.2 3.8 1.6-7L2 9.2l7.1-.6z"/></svg>
            ${Number(film.rating).toFixed(1)}
          </span>
          <p class="note" data-action="open-detail">${film.note}</p>
          <div class="link-row">
            <button class="link-btn detail-btn" data-action="open-detail" type="button">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8v.01"/></svg> Details
            </button>
            <a class="link-btn trailer" href="${trailer}" target="_blank" rel="noopener">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="16" rx="1"/><path d="M7 4v16M17 4v16M3 9h4M17 9h4M3 15h4M17 15h4"/></svg> Trailer
            </a>
            <a class="link-btn watch" href="${watch}" target="_blank" rel="noopener">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M10 8.5l6 3.5-6 3.5v-7z" fill="currentColor" stroke="none"/></svg> Watch
            </a>
          </div>
        </div>
      </article>`;
  }

  function sortFilms(list, sortKey) {
    const copy = [...list];
    if (sortKey === "year") {
      copy.sort((a, b) => b.year - a.year || b.rating - a.rating);
    } else if (sortKey === "title") {
      copy.sort((a, b) => a.title.localeCompare(b.title));
    } else {
      copy.sort((a, b) => b.rating - a.rating || a.title.localeCompare(b.title));
    }
    return copy;
  }

  function paintGrid(list, highlightKey) {
    resultsBody.innerHTML = '<div class="grid">' +
      list.map((film, i) => buildCard(film, i + 1, Math.min(i * 0.03, 0.6))).join("") +
      '</div>';
    attachCardListeners();
    if (window.PosterResolver) window.PosterResolver.observeWithin(resultsBody);
    if (highlightKey) {
      const card = resultsBody.querySelector(`.ticket[data-key="${CSS.escape(highlightKey)}"]`);
      if (card) {
        card.classList.add("highlight");
        card.scrollIntoView({ behavior: "smooth", block: "center" });
        setTimeout(() => card.classList.remove("highlight"), 2000);
      }
    }
  }

  function attachCardListeners() {
    // Heart toggle buttons
    resultsBody.querySelectorAll(".heart-btn").forEach(btn => {
      btn.addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        const key = btn.dataset.key;
        const film = ALL_FILMS.find(f => filmKey(f) === key);
        if (film) toggleWatchlist(key, film, btn);
      });
    });

    // Open detail modal on click
    resultsBody.querySelectorAll("[data-action='open-detail']").forEach(el => {
      el.addEventListener("click", (e) => {
        const ticket = el.closest(".ticket");
        if (!ticket) return;
        const key = ticket.dataset.key;
        const film = ALL_FILMS.find(f => filmKey(f) === key);
        if (film) openHeroModal(film);
      });
    });
  }

  // --- Cinematic Movie Detail / Opening Modal ---
  async function openHeroModal(film) {
    activeModalFilm = film;
    const key = filmKey(film);
    const isSaved = watchlist.has(key);
    const fallback = (window.PosterResolver && window.PosterResolver.FALLBACK) || "/assets/fallback-poster.svg";

    modalBackdrop.style.backgroundImage = "";
    modalPoster.src = fallback;
    modalPoster.alt = `${film.title} Poster`;
    modalTitle.textContent = film.title;
    modalYear.textContent = film.year;
    modalRating.textContent = Number(film.rating).toFixed(1);
    modalGenre.textContent = film.genre_label || film.genre.toUpperCase();
    modalNote.textContent = film.note;

    modalWatchBtn.href = watchSearchUrl(film.title);
    modalTrailerBtn.href = trailerSearchUrl(film.title, film.year);

    updateModalListButton(isSaved);

    movieModal.hidden = false;
    document.body.style.overflow = "hidden";

    if (window.PosterResolver) {
      const url = await window.PosterResolver.fetchPosterUrl(film.title, film.year);
      if (url && activeModalFilm === film) {
        modalPoster.src = url;
        modalBackdrop.style.backgroundImage = `url('${url}')`;
      }
    }
  }

  function updateModalListButton(isSaved) {
    modalListBtn.classList.toggle("active", isSaved);
    modalListBtn.innerHTML = isSaved
      ? '<svg viewBox="0 0 24 24"><path d="M12 21s-7.5-4.6-10-9.2C.5 8.4 2.3 5 6 5c2.1 0 3.6 1.2 4.5 2.6C11.4 6.2 12.9 5 15 5c3.7 0 5.5 3.4 4 6.8C19.5 16.4 12 21 12 21z"/></svg> In My List'
      : '<svg viewBox="0 0 24 24"><path d="M12 21s-7.5-4.6-10-9.2C.5 8.4 2.3 5 6 5c2.1 0 3.6 1.2 4.5 2.6C11.4 6.2 12.9 5 15 5c3.7 0 5.5 3.4 4 6.8C19.5 16.4 12 21 12 21z"/></svg> Add to My List';
  }

  function closeHeroModal() {
    movieModal.hidden = true;
    document.body.style.overflow = "";
    activeModalFilm = null;
  }

  if (modalCloseBtn) modalCloseBtn.addEventListener("click", closeHeroModal);
  if (movieModal) {
    movieModal.addEventListener("click", (e) => {
      if (e.target === movieModal) closeHeroModal();
    });
  }

  if (modalListBtn) {
    modalListBtn.addEventListener("click", () => {
      if (activeModalFilm) {
        toggleWatchlist(filmKey(activeModalFilm), activeModalFilm);
      }
    });
  }

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && movieModal && !movieModal.hidden) {
      closeHeroModal();
    }
  });

  function updateSortUI() {
    sortControl.querySelectorAll(".sort-btn").forEach(b => {
      b.classList.toggle("active", b.dataset.sort === currentSort);
    });
  }

  function render(genreKey, opts) {
    opts = opts || {};
    const genre = DATA[genreKey];
    if (!genre) return;
    const ranked = sortFilms(genre.films, currentSort);

    currentView = { type: "genre", key: genreKey };
    resultsLabel.textContent = "Top 60";
    resultsTitle.textContent = "Top 60 " + genre.label + " Movies";
    resultsCount.textContent = ranked.length + " films";
    sortControl.hidden = false;
    updateSortUI();

    paintGrid(ranked, opts.highlightKey);

    buttons.forEach(b => b.classList.toggle("active", b.dataset.genre === genreKey));
    syncMiniNav(genreKey);
    if (!opts.silent) resultsSection.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function renderWatchlist(opts) {
    opts = opts || {};
    currentView = { type: "watchlist", key: null };
    const saved = ALL_FILMS.filter(f => watchlist.has(filmKey(f)));
    const ranked = sortFilms(saved, currentSort);

    resultsLabel.textContent = "Saved";
    resultsTitle.textContent = "My List";
    resultsCount.textContent = ranked.length + (ranked.length === 1 ? " film" : " films");
    sortControl.hidden = ranked.length === 0;
    updateSortUI();

    if (ranked.length === 0) {
      resultsBody.innerHTML = '<div class="empty-state"><p class="placeholder">Nothing saved yet — tap the heart on any card to add it to your list.</p></div>';
    } else {
      paintGrid(ranked, opts.highlightKey);
    }

    buttons.forEach(b => b.classList.toggle("active", b.dataset.genre === "watchlist"));
    syncMiniNav("watchlist");
    if (!opts.silent) resultsSection.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  function runSearch(query, opts) {
    opts = opts || {};
    const q = (query || "").trim().toLowerCase();
    buttons.forEach(b => b.classList.remove("active"));

    if (searchClearBtn) {
      searchClearBtn.hidden = !q;
    }

    if (!q) {
      currentView = { type: "none", key: null };
      resultsLabel.textContent = "Top 60";
      resultsTitle.textContent = "Pick a genre above";
      resultsCount.textContent = "";
      sortControl.hidden = true;
      resultsBody.innerHTML = '<p class="placeholder">Your list will appear here, ranked highest IMDb rating first.</p>';
      syncMiniNav(null);
      return;
    }

    currentView = { type: "search", key: query };
    syncMiniNav(null);

    const matches = sortFilms(
      ALL_FILMS.filter(f =>
        f.title.toLowerCase().includes(q) ||
        f.note.toLowerCase().includes(q) ||
        (f.genreLabel && f.genreLabel.toLowerCase().includes(q)) ||
        String(f.year).includes(q)
      ),
      currentSort
    );

    resultsLabel.textContent = "Search";
    resultsTitle.textContent = `Search: "${query.trim()}"`;
    sortControl.hidden = matches.length === 0;
    updateSortUI();

    if (matches.length === 0) {
      resultsCount.textContent = "0 films";
      resultsBody.innerHTML = `
        <div class="empty-state">
          <p class="placeholder">No movies found matching "${query}".</p>
          <button class="reset-search-btn" id="reset-search-btn" type="button">Clear search</button>
        </div>`;
      const rBtn = document.getElementById("reset-search-btn");
      if (rBtn) {
        rBtn.addEventListener("click", () => {
          searchInput.value = "";
          runSearch("");
        });
      }
      return;
    }

    resultsCount.textContent = matches.length + (matches.length === 1 ? " film" : " films");
    paintGrid(matches);
    if (!opts.silent) resultsSection.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  // Search input listeners with debouncing
  searchInput.addEventListener("input", (e) => {
    clearTimeout(searchDebounceTimer);
    searchDebounceTimer = setTimeout(() => {
      runSearch(e.target.value);
    }, 150);
  });

  if (searchClearBtn) {
    searchClearBtn.addEventListener("click", () => {
      searchInput.value = "";
      searchInput.focus();
      runSearch("");
    });
  }

  // Genre button triggers
  buttons.forEach(btn => {
    btn.addEventListener("click", () => {
      searchInput.value = "";
      if (searchClearBtn) searchClearBtn.hidden = true;
      if (btn.dataset.genre === "watchlist") renderWatchlist();
      else render(btn.dataset.genre);
    });
  });

  // Sort control
  sortControl.addEventListener("click", (e) => {
    const btn = e.target.closest(".sort-btn");
    if (!btn) return;
    currentSort = btn.dataset.sort;
    updateSortUI();
    if (currentView.type === "genre") render(currentView.key, { silent: true });
    else if (currentView.type === "watchlist") renderWatchlist({ silent: true });
    else if (currentView.type === "search") runSearch(currentView.key, { silent: true });
  });

  // Surprise Me
  surpriseBtn.addEventListener("click", () => {
    if (!ALL_FILMS.length) return;
    const pick = ALL_FILMS[Math.floor(Math.random() * ALL_FILMS.length)];
    surpriseBtn.classList.add("spinning");
    setTimeout(() => surpriseBtn.classList.remove("spinning"), 500);
    searchInput.value = "";
    if (searchClearBtn) searchClearBtn.hidden = true;

    const genreKey = Object.keys(DATA).find(k => DATA[k].films.some(f => filmKey(f) === filmKey(pick)));
    render(genreKey, { highlightKey: filmKey(pick) });
    setTimeout(() => openHeroModal(pick), 400);
  });

  // Mini Nav
  function syncMiniNav(activeKey) {
    miniGenres.querySelectorAll(".mini-btn").forEach(b => {
      b.classList.toggle("active", b.dataset.genre === activeKey);
    });
    miniWatchlistBtn.classList.toggle("active", activeKey === "watchlist");
  }

  miniTitle.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));
  miniWatchlistBtn.addEventListener("click", () => {
    searchInput.value = "";
    if (searchClearBtn) searchClearBtn.hidden = true;
    renderWatchlist();
  });

  let lastScrollShow = false;
  window.addEventListener("scroll", () => {
    const show = window.scrollY > window.innerHeight * 0.7;
    if (show !== lastScrollShow) {
      miniNav.classList.toggle("visible", show);
      lastScrollShow = show;
    }
  }, { passive: true });

  // Initialize dataset from backend or fallback seed
  async function initData() {
    try {
      let movies = [];
      try {
        const res = await window.API.getAllMovies();
        movies = res.movies || [];
      } catch (err) {
        movies = window.__INITIAL_MOVIES__ || [];
      }
      if (!movies || movies.length === 0) {
        movies = window.__INITIAL_MOVIES__ || [];
      }

      // Group into DATA object matching the 4 genres
      DATA = {
        romance: { label: "Romantic", films: [] },
        action: { label: "Action", films: [] },
        scifi: { label: "Science Fiction", films: [] },
        drama: { label: "Drama", films: [] }
      };

      for (const m of movies) {
        if (DATA[m.genre]) {
          DATA[m.genre].films.push(m);
        }
      }

      ALL_FILMS = Object.values(DATA).flatMap(g => g.films.map(f => ({ ...f, genreLabel: g.label })));

      // Populate mini genres nav
      miniGenres.innerHTML = '';
      Object.keys(DATA).forEach(key => {
        const b = document.createElement("button");
        b.className = "mini-btn";
        b.dataset.genre = key;
        b.textContent = DATA[key].label;
        b.addEventListener("click", () => {
          searchInput.value = "";
          if (searchClearBtn) searchClearBtn.hidden = true;
          render(key);
        });
        miniGenres.appendChild(b);
      });
    } catch (e) {
      console.error('Failed to load movies from API', e);
    }
  }

  // Lifecycle
  async function init() {
    await initData();
    if (window.Auth) window.Auth.init();
    await loadWatchlist();
  }

  window.MovieApp = {
    async onLoginSuccess() {
      // Sync local watchlist items to cloud
      const localSaved = JSON.parse(localStorage.getItem("bestmovies_watchlist") || "[]");
      if (localSaved.length > 0) {
        try {
          await window.API.syncWatchlist(localSaved);
          localStorage.removeItem("bestmovies_watchlist");
        } catch (e) {
          console.warn('Sync failed', e);
        }
      }
      await loadWatchlist();
    },
    async onLogoutSuccess() {
      await loadWatchlist();
    }
  };

  init();
})();
