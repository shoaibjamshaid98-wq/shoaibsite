const rateLimit = require("express-rate-limit");

function jsonRateLimitHandler(message) {
  return (req, res) => {
    res.status(429).json({ error: message });
  };
}

// Requesting an OTP: fairly strict, per-IP. (Per-email throttling is handled
// separately in utils/otp.js so an attacker can't just rotate IPs to spam
// one victim's inbox, and can't hammer many emails from one IP either.)
const otpRequestLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 8,
  standardHeaders: true,
  legacyHeaders: false,
  handler: jsonRateLimitHandler("Too many code requests. Please wait a while before trying again."),
});

// Verifying an OTP: stricter still, to blunt brute-forcing a 6-digit code.
const otpVerifyLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 20,
  standardHeaders: true,
  legacyHeaders: false,
  handler: jsonRateLimitHandler("Too many attempts. Please wait a while before trying again."),
});

// General auth endpoints (login, callback, logout).
const authLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  limit: 60,
  standardHeaders: true,
  legacyHeaders: false,
  handler: jsonRateLimitHandler("Too many requests. Please slow down."),
});

// Generous default for the rest of the API.
const generalLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 120,
  standardHeaders: true,
  legacyHeaders: false,
  handler: jsonRateLimitHandler("Too many requests. Please slow down."),
});

module.exports = { otpRequestLimiter, otpVerifyLimiter, authLimiter, generalLimiter };
