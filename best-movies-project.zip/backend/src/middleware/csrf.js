const crypto = require("crypto");

const CSRF_COOKIE = "csrf_token";
const CSRF_HEADER = "x-csrf-token";
const SAFE_METHODS = new Set(["GET", "HEAD", "OPTIONS"]);

/**
 * Double-submit-cookie CSRF protection.
 *
 * Why this pattern: the frontend is a static file served from the same
 * origin as the API, with no server-side templating step to inject a token
 * into the HTML. The double-submit pattern needs no template — the server
 * hands the browser a random token via a readable (non-HttpOnly) cookie,
 * and the frontend JS must echo that exact value back in a custom header
 * on any state-changing request. A cross-site form post or <img> tag can
 * make the browser SEND the cookie automatically, but it cannot READ the
 * cookie's value to put it in a custom header — so a forged request fails.
 *
 * The token itself carries no secret meaning; its value only has to be
 * (a) unguessable and (b) provably readable only by same-origin JS.
 */
function ensureCsrfCookie(req, res, next) {
  if (!req.cookies || !req.cookies[CSRF_COOKIE]) {
    const token = crypto.randomBytes(32).toString("hex");
    res.cookie(CSRF_COOKIE, token, {
      httpOnly: false, // must be readable by frontend JS
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
    });
    req.cookies = req.cookies || {};
    req.cookies[CSRF_COOKIE] = token;
  }
  next();
}

function verifyCsrf(req, res, next) {
  if (SAFE_METHODS.has(req.method)) return next();

  const cookieToken = req.cookies && req.cookies[CSRF_COOKIE];
  const headerToken = req.get(CSRF_HEADER);

  if (!cookieToken || !headerToken || cookieToken !== headerToken) {
    return res.status(403).json({ error: "Request could not be verified. Please refresh and try again." });
  }
  next();
}

module.exports = { ensureCsrfCookie, verifyCsrf, CSRF_COOKIE, CSRF_HEADER };
