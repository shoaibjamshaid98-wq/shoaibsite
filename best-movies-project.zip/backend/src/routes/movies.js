const express = require("express");
const movies = require("../data/movies.json");

const router = express.Router();

const GENRES = new Set(movies.map((m) => m.genre));

router.get("/", (req, res) => {
  res.json({ movies, count: movies.length });
});

router.get("/genre/:genre", (req, res) => {
  const genre = String(req.params.genre || "").toLowerCase();
  if (!GENRES.has(genre)) {
    return res.status(404).json({ error: "Unknown genre." });
  }
  const filtered = movies.filter((m) => m.genre === genre);
  res.json({ movies: filtered, count: filtered.length });
});

router.get("/search", (req, res) => {
  const q = String(req.query.q || "").trim().toLowerCase();
  if (!q) return res.json({ movies: [], count: 0 });
  if (q.length > 200) return res.status(400).json({ error: "Search query too long." });

  const results = movies.filter(
    (m) => m.title.toLowerCase().includes(q) || m.note.toLowerCase().includes(q)
  );
  res.json({ movies: results, count: results.length });
});

module.exports = router;
