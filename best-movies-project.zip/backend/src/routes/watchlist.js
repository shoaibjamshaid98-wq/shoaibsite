const express = require("express");
const db = require("../db");
const requireAuth = require("../middleware/requireAuth");

const router = express.Router();

function keyOf(title, year) {
  return `${title}__${year}`;
}

function sanitizeTitle(title) {
  const t = String(title || "").trim();
  return t.slice(0, 300); // guard against absurdly long input
}

function sanitizeYear(year) {
  const y = parseInt(year, 10);
  if (!Number.isFinite(y) || y < 1870 || y > 2100) return null;
  return y;
}

router.use(requireAuth);

// GET /api/watchlist — the caller's own items only.
router.get("/", (req, res) => {
  const rows = db
    .prepare(`SELECT movie_id, title, year, genre FROM watchlist_items WHERE user_id = ? ORDER BY created_at DESC`)
    .all(req.session.userId);

  res.json({
    watchlist: rows,
    keys: rows.map((r) => keyOf(r.title, r.year)),
  });
});

// POST /api/watchlist — add one item.
router.post("/", (req, res) => {
  const title = sanitizeTitle(req.body && req.body.title);
  const year = sanitizeYear(req.body && req.body.year);
  const genre = req.body && req.body.genre ? String(req.body.genre).slice(0, 50) : null;
  const movieId = req.body && Number.isFinite(Number(req.body.movieId)) ? Number(req.body.movieId) : null;

  if (!title || !year) {
    return res.status(400).json({ error: "A valid movie title and year are required." });
  }

  try {
    db.prepare(
      `INSERT INTO watchlist_items (user_id, movie_id, title, year, genre)
       VALUES (?, ?, ?, ?, ?)
       ON CONFLICT(user_id, title, year) DO NOTHING`
    ).run(req.session.userId, movieId, title, year, genre);
    res.json({ ok: true });
  } catch (err) {
    console.error("[watchlist] add error:", err.message);
    res.status(500).json({ error: "Could not update your list right now." });
  }
});

// DELETE /api/watchlist/by-title?title=&year=
router.delete("/by-title", (req, res) => {
  const title = sanitizeTitle(req.query.title);
  const year = sanitizeYear(req.query.year);

  if (!title || !year) {
    return res.status(400).json({ error: "A valid movie title and year are required." });
  }

  db.prepare(`DELETE FROM watchlist_items WHERE user_id = ? AND title = ? AND year = ?`).run(
    req.session.userId,
    title,
    year
  );
  res.json({ ok: true });
});

// POST /api/watchlist/sync — merges guest (localStorage) items, keyed as "Title__Year", into the account.
router.post("/sync", (req, res) => {
  const items = Array.isArray(req.body && req.body.items) ? req.body.items : [];
  if (items.length > 1000) {
    return res.status(400).json({ error: "Too many items to sync." });
  }

  const insert = db.prepare(
    `INSERT INTO watchlist_items (user_id, title, year)
     VALUES (?, ?, ?)
     ON CONFLICT(user_id, title, year) DO NOTHING`
  );

  const runAll = db.transaction((keys) => {
    for (const raw of keys) {
      if (typeof raw !== "string") continue;
      const idx = raw.lastIndexOf("__");
      if (idx === -1) continue;
      const title = sanitizeTitle(raw.slice(0, idx));
      const year = sanitizeYear(raw.slice(idx + 2));
      if (!title || !year) continue;
      insert.run(req.session.userId, title, year);
    }
  });

  try {
    runAll(items);
    res.json({ ok: true });
  } catch (err) {
    console.error("[watchlist] sync error:", err.message);
    res.status(500).json({ error: "Could not sync your list right now." });
  }
});

module.exports = router;
