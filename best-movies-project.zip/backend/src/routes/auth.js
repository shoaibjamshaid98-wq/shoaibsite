const express = require("express");
const crypto = require("crypto");
const validator = require("validator");

const { otpRequestLimiter, otpVerifyLimiter, authLimiter } = require("../middleware/rateLimiters");
const otp = require("../utils/otp");
const mailer = require("../utils/mailer");
const googleAuth = require("../utils/googleAuth");
const users = require("../db/users");

const router = express.Router();

const FRONTEND_URL = process.env.FRONTEND_URL || "/";

function regenerateSession(req) {
  return new Promise((resolve, reject) => {
    req.session.regenerate((err) => (err ? reject(err) : resolve()));
  });
}

function redirectWithParam(res, key, value) {
  const sep = FRONTEND_URL.includes("?") ? "&" : "?";
  res.redirect(`${FRONTEND_URL}${sep}${key}=${encodeURIComponent(value)}`);
}

// ---------------------------------------------------------------------------
// Session check
// ---------------------------------------------------------------------------
router.get("/me", (req, res) => {
  if (!req.session || !req.session.userId) return res.json({ user: null });
  const user = users.findById(req.session.userId);
  if (!user) return res.json({ user: null });
  res.json({ user: users.toPublicUser(user) });
});

// ---------------------------------------------------------------------------
// Google OAuth 2.0 / OpenID Connect
// ---------------------------------------------------------------------------
router.get("/google", authLimiter, (req, res) => {
  if (!googleAuth.isGoogleConfigured()) {
    return redirectWithParam(res, "auth_error", "google_not_configured");
  }
  const state = crypto.randomBytes(24).toString("hex");
  req.session.oauthState = state;
  const url = googleAuth.buildAuthUrl(state);
  res.redirect(url);
});

router.get("/google/callback", authLimiter, async (req, res) => {
  try {
    if (req.query.error) {
      // e.g. the user clicked "Cancel" on Google's consent screen.
      return redirectWithParam(res, "auth_error", "cancelled");
    }

    const { code, state } = req.query;
    if (!code || !state || state !== req.session.oauthState) {
      return redirectWithParam(res, "auth_error", "invalid_state");
    }
    delete req.session.oauthState;

    const profile = await googleAuth.exchangeCodeAndVerify(code);

    if (!profile.emailVerified) {
      return redirectWithParam(res, "auth_error", "email_not_verified");
    }

    const user = users.findOrCreateByGoogle({
      sub: profile.sub,
      email: profile.email,
      name: profile.name,
      picture: profile.picture,
    });

    // Session fixation protection: issue a brand-new session id on login.
    await regenerateSession(req);
    req.session.userId = user.id;

    redirectWithParam(res, "login", "google_success");
  } catch (err) {
    // Detailed error stays server-side; the user only ever sees a generic code.
    console.error("[auth] Google callback error:", err.message);
    redirectWithParam(res, "auth_error", "server_error");
  }
});

// ---------------------------------------------------------------------------
// Email OTP
// ---------------------------------------------------------------------------
router.post("/email/request-otp", otpRequestLimiter, async (req, res) => {
  const rawEmail = (req.body && req.body.email) || "";
  const email = String(rawEmail).trim().toLowerCase();

  if (!email || !validator.isEmail(email) || email.length > 254) {
    return res.status(400).json({ error: "Please enter a valid email address." });
  }

  const throttle = otp.checkEmailRequestThrottle(email);
  if (!throttle.allowed) {
    return res.status(429).json({ error: "Too many code requests for this email. Please try again later." });
  }

  try {
    const code = otp.createOtp(email);
    otp.logEmailRequest(email);
    const result = await mailer.sendOtpEmail(email, code);
    res.json({ ok: true, isDevConsole: Boolean(result.devConsole) });
  } catch (err) {
    console.error("[auth] Failed to send OTP email:", err.message);
    res.status(503).json({ error: "We couldn't send the email right now. Please try again shortly." });
  }
});

router.post("/email/verify-otp", otpVerifyLimiter, async (req, res) => {
  const rawEmail = (req.body && req.body.email) || "";
  const rawCode = (req.body && req.body.code) || "";
  const email = String(rawEmail).trim().toLowerCase();
  const code = String(rawCode).trim();

  if (!email || !validator.isEmail(email) || !/^\d{6}$/.test(code)) {
    return res.status(400).json({ error: "Invalid or expired code." });
  }

  const result = otp.verifyOtp(email, code);

  if (!result.ok) {
    const messages = {
      none: "Invalid or expired code.",
      invalid: "Invalid or expired code.",
      expired: "Verification code expired. Please request a new one.",
      too_many_attempts: "Too many attempts. Please request a new code.",
    };
    return res.status(400).json({ error: messages[result.reason] || "Invalid or expired code." });
  }

  const user = users.findOrCreateByEmail(email);

  // Session fixation protection: issue a brand-new session id on login.
  await regenerateSession(req);
  req.session.userId = user.id;

  res.json({ ok: true, user: users.toPublicUser(user) });
});

// ---------------------------------------------------------------------------
// Logout
// ---------------------------------------------------------------------------
router.post("/logout", (req, res) => {
  if (!req.session) return res.json({ ok: true });
  const cookieName = req.session.cookie ? "connect.sid" : null;
  req.session.destroy((err) => {
    if (err) console.error("[auth] Session destroy error:", err.message);
    if (cookieName) res.clearCookie(cookieName);
    res.json({ ok: true });
  });
});

module.exports = router;
