const nodemailer = require("nodemailer");

let transporter = null;
let smtpConfigured = false;

function getTransporter() {
  if (transporter) return transporter;

  const { SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_SECURE } = process.env;

  if (SMTP_HOST && SMTP_USER && SMTP_PASS) {
    transporter = nodemailer.createTransport({
      host: SMTP_HOST,
      port: Number(SMTP_PORT) || 587,
      secure: String(SMTP_SECURE).toLowerCase() === "true", // true for port 465
      auth: { user: SMTP_USER, pass: SMTP_PASS },
    });
    smtpConfigured = true;
  }

  return transporter;
}

/**
 * Sends the OTP email. Returns { delivered: boolean, devConsole: boolean }.
 *
 * SECURITY: the OTP is never returned to the HTTP caller and never written
 * to persistent logs. The ONLY place it may appear outside the recipient's
 * inbox is a single console.log gated behind NODE_ENV !== 'production',
 * purely so a developer can test the flow locally without configuring SMTP.
 */
async function sendOtpEmail(email, code) {
  const t = getTransporter();
  const fromAddress = process.env.EMAIL_FROM || "Best Movies <no-reply@bestmovies.app>";

  if (!t) {
    if (process.env.NODE_ENV === "production") {
      // Fail loudly in production rather than silently "succeeding" with no email sent.
      throw new Error("Email service is not configured (missing SMTP_HOST/SMTP_USER/SMTP_PASS).");
    }
    // Local development convenience only — never do this in production.
    // eslint-disable-next-line no-console
    console.log(`\n[DEV ONLY] OTP for ${email}: ${code} (expires in 10 min)\n`);
    return { delivered: true, devConsole: true };
  }

  await t.sendMail({
    from: fromAddress,
    to: email,
    subject: "Your Best Movies sign-in code",
    text: `Your verification code is ${code}. It expires in 10 minutes. If you didn't request this, you can ignore this email.`,
    html: `<p>Your verification code is:</p>
           <p style="font-size:28px;font-weight:700;letter-spacing:4px;">${code}</p>
           <p>It expires in 10 minutes. If you didn't request this, you can safely ignore this email.</p>`,
  });

  return { delivered: true, devConsole: false };
}

module.exports = { sendOtpEmail, isSmtpConfigured: () => smtpConfigured };
