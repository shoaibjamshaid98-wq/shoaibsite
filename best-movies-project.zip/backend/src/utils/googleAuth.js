const { OAuth2Client } = require("google-auth-library");

function isGoogleConfigured() {
  return Boolean(
    process.env.GOOGLE_CLIENT_ID &&
      process.env.GOOGLE_CLIENT_SECRET &&
      process.env.GOOGLE_REDIRECT_URI
  );
}

function getClient() {
  return new OAuth2Client(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET,
    process.env.GOOGLE_REDIRECT_URI
  );
}

function buildAuthUrl(state) {
  const client = getClient();
  return client.generateAuthUrl({
    access_type: "online",
    // Ask only for what we need — least privilege.
    scope: ["openid", "email", "profile"],
    state,
    prompt: "select_account",
  });
}

/**
 * Exchanges an authorization code for tokens, then verifies the ID token
 * signature, issuer, audience and expiry server-side (never trust a token
 * the browser hands you without verifying it against Google's public keys).
 *
 * Returns the verified payload: { sub, email, email_verified, name, picture }
 */
async function exchangeCodeAndVerify(code) {
  const client = getClient();
  const { tokens } = await client.getToken(code);

  if (!tokens.id_token) {
    throw new Error("Google did not return an id_token.");
  }

  const ticket = await client.verifyIdToken({
    idToken: tokens.id_token,
    audience: process.env.GOOGLE_CLIENT_ID, // must match our own client id
  });

  const payload = ticket.getPayload();

  // verifyIdToken() already validates signature, issuer (accounts.google.com /
  // https://accounts.google.com), audience, and expiry — but we re-assert the
  // issuer explicitly as defense in depth against library misconfiguration.
  const validIssuers = ["accounts.google.com", "https://accounts.google.com"];
  if (!validIssuers.includes(payload.iss)) {
    throw new Error("Unexpected token issuer.");
  }

  if (!payload.email) {
    throw new Error("Google account has no email on file.");
  }

  return {
    sub: payload.sub,
    email: payload.email,
    emailVerified: Boolean(payload.email_verified),
    name: payload.name || null,
    picture: payload.picture || null,
  };
}

module.exports = { isGoogleConfigured, buildAuthUrl, exchangeCodeAndVerify };
