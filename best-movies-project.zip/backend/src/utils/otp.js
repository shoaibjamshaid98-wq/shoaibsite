const crypto = require("crypto");
const bcrypt = require("bcryptjs");
const db = require("../db");

const OTP_LENGTH = 6;
const OTP_TTL_MINUTES = 10;
const MAX_VERIFY_ATTEMPTS = 5;
const BCRYPT_ROUNDS = 10;

// Per-email request throttling (separate from the IP-based express-rate-limit
// middleware — this stops one email address being hammered from many IPs).
const MAX_REQUESTS_PER_WINDOW = 3;
const REQUEST_WINDOW_MINUTES = 15;

/** Cryptographically-secure random numeric code, e.g. "042917". */
function generateCode() {
  // Random integer in [0, 999999], zero-padded to 6 digits.
  const max = 10 ** OTP_LENGTH;
  const n = crypto.randomInt(0, max);
  return String(n).padStart(OTP_LENGTH, "0");
}

function hashCode(code) {
  return bcrypt.hashSync(code, BCRYPT_ROUNDS);
}

/**
 * Returns { allowed: boolean, retryAfterSeconds } — whether this email may
 * request another OTP right now.
 */
function checkEmailRequestThrottle(email) {
  const row = db
    .prepare(
      `SELECT COUNT(*) AS cnt, MIN(created_at) AS earliest
       FROM otp_request_log
       WHERE email = ? AND created_at >= datetime('now', ?)`
    )
    .get(email, `-${REQUEST_WINDOW_MINUTES} minutes`);

  if (row.cnt >= MAX_REQUESTS_PER_WINDOW) {
    return { allowed: false, retryAfterSeconds: REQUEST_WINDOW_MINUTES * 60 };
  }
  return { allowed: true, retryAfterSeconds: 0 };
}

function logEmailRequest(email) {
  db.prepare(`INSERT INTO otp_request_log (email) VALUES (?)`).run(email);
}

/**
 * Creates a new OTP for the given email, invalidating any prior unconsumed
 * codes for that email. Returns the PLAINTEXT code (caller must email it
 * and must never persist or log the plaintext).
 */
function createOtp(email) {
  // Invalidate any previous outstanding codes for this email.
  db.prepare(
    `UPDATE otp_codes SET consumed_at = datetime('now')
     WHERE email = ? AND consumed_at IS NULL`
  ).run(email);

  const code = generateCode();
  const codeHash = hashCode(code);
  const expiresAt = new Date(Date.now() + OTP_TTL_MINUTES * 60 * 1000).toISOString();

  db.prepare(
    `INSERT INTO otp_codes (email, code_hash, expires_at, max_attempts)
     VALUES (?, ?, ?, ?)`
  ).run(email, codeHash, expiresAt, MAX_VERIFY_ATTEMPTS);

  return code;
}

/**
 * Verifies a submitted code against the latest outstanding OTP for the email.
 * Returns { ok: true } | { ok: false, reason: 'expired'|'invalid'|'too_many_attempts'|'none' }
 */
function verifyOtp(email, submittedCode) {
  const row = db
    .prepare(
      `SELECT * FROM otp_codes
       WHERE email = ? AND consumed_at IS NULL
       ORDER BY id DESC LIMIT 1`
    )
    .get(email);

  if (!row) return { ok: false, reason: "none" };

  if (row.attempts >= row.max_attempts) {
    return { ok: false, reason: "too_many_attempts" };
  }

  if (new Date(row.expires_at).getTime() < Date.now()) {
    return { ok: false, reason: "expired" };
  }

  const matches = bcrypt.compareSync(String(submittedCode), row.code_hash);

  if (!matches) {
    db.prepare(`UPDATE otp_codes SET attempts = attempts + 1 WHERE id = ?`).run(row.id);
    return { ok: false, reason: "invalid" };
  }

  // Success — consume the code so it cannot be reused.
  db.prepare(`UPDATE otp_codes SET consumed_at = datetime('now') WHERE id = ?`).run(row.id);
  return { ok: true };
}

module.exports = {
  createOtp,
  verifyOtp,
  checkEmailRequestThrottle,
  logEmailRequest,
  OTP_TTL_MINUTES,
};
