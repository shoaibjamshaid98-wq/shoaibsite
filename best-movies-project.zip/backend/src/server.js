require("dotenv").config();

const path = require("path");
const express = require("express");
const helmet = require("helmet");
const cors = require("cors");
const cookieParser = require("cookie-parser");
const session = require("express-session");
const SQLiteStore = require("connect-sqlite3")(session);

const { ensureCsrfCookie, verifyCsrf } = require("./middleware/csrf");
const { generalLimiter } = require("./middleware/rateLimiters");
const authRoutes = require("./routes/auth");
const movieRoutes = require("./routes/movies");
const watchlistRoutes = require("./routes/watchlist");

const app = express();
const isProd = process.env.NODE_ENV === "production";
const PORT = process.env.PORT || 3000;

if (isProd && !process.env.SESSION_SECRET) {
  // Fail fast rather than silently running with an insecure default secret.
  console.error("FATAL: SESSION_SECRET must be set in production. See .env.example.");
  process.exit(1);
}

// Behind a reverse proxy (Render, Railway, Fly, nginx, etc.) in production,
// this is required for secure cookies and req.secure to work correctly.
app.set("trust proxy", 1);

// ---------------------------------------------------------------------------
// Security headers
// ---------------------------------------------------------------------------
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        // The frontend's inline <style> block still needs 'unsafe-inline';
        // its former inline <script> was extracted to /app.js specifically
        // so script-src can stay strict (no 'unsafe-inline', no 'unsafe-eval').
        scriptSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
        fontSrc: ["'self'", "https://fonts.gstatic.com"],
        imgSrc: [
          "'self'",
          "data:",
          "https://is1-ssl.mzstatic.com",
          "https://is2-ssl.mzstatic.com",
          "https://is3-ssl.mzstatic.com",
          "https://is4-ssl.mzstatic.com",
          "https://is5-ssl.mzstatic.com",
          "https://*.googleusercontent.com", // Google account profile pictures
        ],
        connectSrc: ["'self'", "https://itunes.apple.com"],
        formAction: ["'self'", "https://accounts.google.com"],
        frameAncestors: ["'self'"],
        objectSrc: ["'none'"],
        baseUri: ["'self'"],
        upgradeInsecureRequests: isProd ? [] : null,
      },
    },
    crossOriginEmbedderPolicy: false, // would otherwise block the Google Fonts / iTunes assets above
  })
);
app.use(helmet.referrerPolicy({ policy: "strict-origin-when-cross-origin" }));

// ---------------------------------------------------------------------------
// CORS — same-origin by default. Only relevant if you deploy the frontend
// on a different origin than this API; set CORS_ORIGIN to that origin.
// ---------------------------------------------------------------------------
if (process.env.CORS_ORIGIN) {
  app.use(
    cors({
      origin: process.env.CORS_ORIGIN.split(",").map((s) => s.trim()),
      credentials: true,
    })
  );
}

// ---------------------------------------------------------------------------
// Body parsing with request size limits (mitigates trivial DoS via huge bodies)
// ---------------------------------------------------------------------------
app.use(express.json({ limit: "20kb" }));
app.use(cookieParser());

// ---------------------------------------------------------------------------
// Sessions — persisted to SQLite so logins survive server restarts, with
// HttpOnly + SameSite + (in production) Secure cookies. Session IDs are
// regenerated on login (see routes/auth.js) to prevent session fixation.
// ---------------------------------------------------------------------------
const SQLITE_DIR = process.env.SQLITE_DIR || path.join(__dirname, "..", "data");

app.use(
  session({
    store: new SQLiteStore({ dir: SQLITE_DIR, db: "sessions.db" }),
    name: "bm.sid",
    secret: process.env.SESSION_SECRET || "dev-only-insecure-secret-change-me",
    resave: false,
    saveUninitialized: false,
    rolling: true,
    cookie: {
      httpOnly: true,
      secure: isProd, // requires HTTPS in production (set NODE_ENV=production behind TLS)
      sameSite: "lax", // 'lax' allows the Google OAuth redirect back to carry the session
      maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
    },
  })
);

app.use(ensureCsrfCookie);

// Generous baseline rate limit across the whole API; stricter limits are
// layered on top for auth-sensitive routes (see routes/auth.js).
app.use("/api", generalLimiter);

// CSRF check applies to all state-changing API requests.
app.use("/api", verifyCsrf);

// ---------------------------------------------------------------------------
// Routes
// ---------------------------------------------------------------------------
app.use("/api/auth", authRoutes);
app.use("/api/movies", movieRoutes);
app.use("/api/watchlist", watchlistRoutes);

app.get("/api/health", (req, res) => res.json({ ok: true }));

// ---------------------------------------------------------------------------
// Static frontend (same origin — keeps cookies/CSRF simple, no separate deploy needed)
// ---------------------------------------------------------------------------
const FRONTEND_DIR = process.env.FRONTEND_DIR || path.join(__dirname, "..", "..", "frontend", "public");
app.use(express.static(FRONTEND_DIR, { maxAge: isProd ? "1h" : 0 }));

app.get("*", (req, res, next) => {
  if (req.path.startsWith("/api/")) return next();
  res.sendFile(path.join(FRONTEND_DIR, "index.html"));
});

// ---------------------------------------------------------------------------
// Error handling — generic messages to the client, full detail server-side only.
// ---------------------------------------------------------------------------
app.use((req, res) => {
  res.status(404).json({ error: "Not found." });
});

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error("[unhandled]", err);
  res.status(500).json({ error: "Server temporarily unavailable. Please try again shortly." });
});

app.listen(PORT, () => {
  console.log(`Best Movies server listening on port ${PORT} (${isProd ? "production" : "development"})`);
});

module.exports = app;
