/**
 * Database layer.
 *
 * Uses SQLite (via better-sqlite3) as an embedded, zero-config,
 * production-viable database for small/medium deployments — no external
 * service required to get the app running.
 *
 * To scale to Postgres/MySQL/Supabase later, this is the ONLY file that
 * needs to change: keep the exported function names/shapes the same
 * (or write an adapter) and swap the implementation below for a real
 * Postgres client (e.g. `pg`). Nothing outside this file talks SQL
 * directly except the session store, which is also swappable
 * (see src/server.js).
 */

const path = require("path");
const fs = require("fs");
const Database = require("better-sqlite3");

const DATA_DIR = process.env.SQLITE_DIR || path.join(__dirname, "..", "..", "data");
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const DB_PATH = path.join(DATA_DIR, "app.db");
const db = new Database(DB_PATH);

db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  email         TEXT NOT NULL UNIQUE,
  name          TEXT,
  avatar_url    TEXT,
  google_sub    TEXT UNIQUE,          -- Google's stable per-user "sub" claim
  auth_provider TEXT NOT NULL DEFAULT 'email', -- 'email' | 'google'
  created_at    TEXT NOT NULL DEFAULT (datetime('now')),
  last_login_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);

-- OTP codes are stored HASHED, never in plain text.
CREATE TABLE IF NOT EXISTS otp_codes (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  email        TEXT NOT NULL,
  code_hash    TEXT NOT NULL,
  expires_at   TEXT NOT NULL,
  attempts     INTEGER NOT NULL DEFAULT 0,
  max_attempts INTEGER NOT NULL DEFAULT 5,
  consumed_at  TEXT,
  created_at   TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_otp_email ON otp_codes(email);

-- Coarse-grained request counters for rate limiting OTP requests per email
-- (in addition to the IP-based express-rate-limit middleware).
CREATE TABLE IF NOT EXISTS otp_request_log (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  email      TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_otp_log_email_time ON otp_request_log(email, created_at);

CREATE TABLE IF NOT EXISTS watchlist_items (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  movie_id   INTEGER,
  title      TEXT NOT NULL,
  year       INTEGER,
  genre      TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE(user_id, title, year)
);

CREATE INDEX IF NOT EXISTS idx_watchlist_user ON watchlist_items(user_id);
`);

module.exports = db;
