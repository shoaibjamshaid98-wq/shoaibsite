const db = require("./index");

function toPublicUser(row) {
  if (!row) return null;
  return {
    id: row.id,
    email: row.email,
    name: row.name,
    avatar_url: row.avatar_url,
  };
}

function findByEmail(email) {
  return db.prepare(`SELECT * FROM users WHERE email = ?`).get(email);
}

function findByGoogleSub(sub) {
  return db.prepare(`SELECT * FROM users WHERE google_sub = ?`).get(sub);
}

function findById(id) {
  return db.prepare(`SELECT * FROM users WHERE id = ?`).get(id);
}

function touchLogin(id) {
  db.prepare(`UPDATE users SET last_login_at = datetime('now') WHERE id = ?`).run(id);
}

/** Find-or-create a user for email/OTP sign-in. */
function findOrCreateByEmail(email) {
  let user = findByEmail(email);
  if (!user) {
    const info = db
      .prepare(`INSERT INTO users (email, auth_provider) VALUES (?, 'email')`)
      .run(email);
    user = findById(info.lastInsertRowid);
  }
  touchLogin(user.id);
  return user;
}

/**
 * Find-or-create/update a user for Google sign-in. Links by google_sub first;
 * falls back to linking an existing email/OTP account with the same
 * (Google-verified) email address, upgrading it to also support Google login.
 */
function findOrCreateByGoogle({ sub, email, name, picture }) {
  let user = findByGoogleSub(sub);

  if (!user) {
    const existingByEmail = findByEmail(email);
    if (existingByEmail) {
      db.prepare(
        `UPDATE users SET google_sub = ?, name = COALESCE(?, name), avatar_url = COALESCE(?, avatar_url)
         WHERE id = ?`
      ).run(sub, name, picture, existingByEmail.id);
      user = findById(existingByEmail.id);
    } else {
      const info = db
        .prepare(
          `INSERT INTO users (email, name, avatar_url, google_sub, auth_provider)
           VALUES (?, ?, ?, ?, 'google')`
        )
        .run(email, name, picture, sub);
      user = findById(info.lastInsertRowid);
    }
  } else {
    // Keep profile info fresh on each login.
    db.prepare(`UPDATE users SET name = ?, avatar_url = ? WHERE id = ?`).run(name, picture, user.id);
    user = findById(user.id);
  }

  touchLogin(user.id);
  return user;
}

module.exports = {
  toPublicUser,
  findByEmail,
  findByGoogleSub,
  findById,
  findOrCreateByEmail,
  findOrCreateByGoogle,
};
