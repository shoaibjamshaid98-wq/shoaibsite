# Best Movies — Setup & Deployment Guide

This project has two parts that deploy together as one app:

```
frontend/public/   Your movie site (index.html + app.js), unchanged in content,
                    240 movies preserved exactly.
backend/            Node.js + Express API: Google OAuth, email OTP, sessions,
                    watchlist, all backed by a local SQLite database.
```

In production the backend serves the frontend directly (same origin), which
is why login, cookies, and CSRF all work with zero extra configuration —
there's only one URL to deal with.

A full backup of your original file is included as
`movies.ORIGINAL.BACKUP.html` at the project root, untouched.

---

## 1. What was actually verified vs. what needs your own testing

I want to be precise about this rather than claim more than I can back up.

**Verified myself, by actually running the code:**
- All 240 movies are present and unchanged after every edit (IDs 1–240, 60
  per genre) — checked programmatically before I started and again after
  every structural change.
- The email OTP flow end-to-end: request → hashed storage → wrong-code
  rejection → correct-code acceptance → code reuse blocked → session issued.
- Sessions: persist across requests, correctly cleared on logout.
- CSRF protection: a request missing the token header is rejected.
- Rate limiting: repeated OTP requests for the same email get throttled.
- Watchlist: add/remove/sync work, and — checked specifically — one user's
  session cannot see another user's watchlist.
- The "Google not configured" fallback path (what happens before you've
  added real credentials).
- Security headers (CSP, X-Frame-Options, etc.) are present and don't block
  the app's own assets.

**I could not test myself, and you'll need to verify after deploying:**
- The actual Google sign-in flow. This needs a real Google Cloud OAuth
  client and a live HTTPS URL for Google to redirect back to — neither
  exists in the sandbox I built this in. The code follows the correct,
  standard pattern (`google-auth-library`, server-side token verification
  checking signature/issuer/audience/expiry), but "correct code" and
  "verified working" are different claims, and I only earned the first one
  here.
- Real email delivery through your SMTP provider (I tested the OTP logic
  using a safe dev-only console fallback, not a real inbox).
- Anything that depends on your actual hosting environment (HTTPS
  certificates, environment variables set correctly in production, etc.)

Section 4 below has a step-by-step checklist for testing the pieces I
couldn't.

---

## 2. Local setup

Requires Node.js 18+.

```bash
cd backend
npm install
cp .env.example .env
# Edit .env — at minimum set SESSION_SECRET for anything beyond quick testing.
npm run dev
```

Open **http://localhost:3000** — the backend serves the frontend automatically.

With no `GOOGLE_CLIENT_ID`/`SECRET` set, the Google button will show a
"Google sign-in isn't configured yet" message instead of pretending to
work — that's intentional, not a bug.

With no `SMTP_*` vars set, requesting an email code will print it to your
terminal instead of sending an email, so you can test the whole sign-in
flow locally before wiring up real email. This **only** happens outside
`NODE_ENV=production` — in production, an unconfigured email service fails
loudly instead of silently doing nothing.

---

## 3. Getting real Google Sign-In working

This is the one piece that genuinely requires action on your end — nobody
(including me) can create Google OAuth credentials on your behalf.

1. Go to the [Google Cloud Console](https://console.cloud.google.com/apis/credentials).
2. Create a project (or use an existing one).
3. Configure the OAuth consent screen (External, unless you're G Suite/Workspace-only).
4. Create an **OAuth client ID** → Application type: **Web application**.
5. Add an **Authorized redirect URI**:
   - Local: `http://localhost:3000/api/auth/google/callback`
   - Production: `https://yourdomain.com/api/auth/google/callback`
6. Copy the generated **Client ID** and **Client Secret** into your `.env`:
   ```
   GOOGLE_CLIENT_ID=...
   GOOGLE_CLIENT_SECRET=...
   GOOGLE_REDIRECT_URI=https://yourdomain.com/api/auth/google/callback
   ```
7. Restart the server. The Google button will now redirect to Google's real
   consent screen.

The client secret only ever lives in `.env` on the server — it's never sent
to the browser, and nothing in `frontend/` references it.

---

## 4. Manual testing checklist (do this after deploying)

- [ ] Click "Continue with Google" → real Google consent screen appears
- [ ] Approve → redirected back, signed in, name/photo shown
- [ ] Click "Cancel" on Google's screen → redirected back with a clean error, not a crash
- [ ] Sign out → session cleared, protected requests now return 401
- [ ] Request an email code → arrives in your inbox within a minute
- [ ] Enter it correctly → signed in
- [ ] Enter it wrong → generic "invalid or expired" message (doesn't leak which part was wrong)
- [ ] Wait for it to expire (10 min) → correctly rejected as expired
- [ ] Request codes rapidly → rate-limited after a few
- [ ] Add movies to your watchlist while signed in → persists after refresh
- [ ] Sign in as a second account → does NOT see the first account's watchlist
- [ ] Log out, add to watchlist as a guest, sign in → guest list merges into your account
- [ ] Load the site on a phone-width screen → nothing overflows, account menu and auth modal stay fully on-screen
- [ ] Throttle your network (or just watch on first load) → posters fade in individually rather than blocking the page; a title iTunes can't find shows the fallback artwork, never a broken-image icon

---

## 5. Deployment

Any Node-friendly host works (Render, Railway, Fly.io, a plain VPS, etc.).
General shape:

1. Push this repo (**without** `.env`, `node_modules/`, or `backend/data/`
   — all already in `.gitignore`).
2. Set the environment variables from `.env.example` in your host's
   dashboard/secrets manager. Generate a real `SESSION_SECRET`:
   ```bash
   node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
   ```
3. Set `NODE_ENV=production`.
4. Point the Google OAuth redirect URI (both in `.env` and in Google Cloud
   Console) at your real production URL.
5. Make sure the platform gives you HTTPS (most do automatically) — secure
   cookies require it in production.
6. `npm install && npm start` (or let the platform run this for you).
7. If your host's disk isn't persistent between deploys, either enable a
   persistent volume for `backend/data/` (SQLite files) or swap the storage
   layer for a hosted Postgres — see the note in `backend/src/db/index.js`,
   which is the only file that needs to change to do that.

---

## 6. What changed vs. your original file, and why

- **Nothing about your 240 movies changed** — same titles, years, ratings,
  notes, genres, ranks. Verified programmatically, not just by eye.
- Your inline `<script>` block was moved to `frontend/public/app.js`,
  unchanged in logic, so the site can run under a strict Content-Security-
  Policy (no `unsafe-inline` for scripts) without weakening XSS protection.
- Removed a ~65KB block of **duplicate, unused** movie data that sat at the
  top of the old script, shadowed by the real dataset and never read by
  anything — dead weight, not a feature.
- Poster images: your existing `poster_url` values were fabricated
  placeholder strings (many different movies shared the exact same fake
  URL), so every poster was silently 404ing to the fallback. Replaced with
  a real, working system: the free iTunes Search API resolves a poster per
  film, lazily (only as cards scroll into view), cached in the browser so
  repeat visits don't re-fetch, with a proper cinematic fallback graphic if
  a title genuinely can't be found — never a broken-image icon.
- Everything else — search, genre tabs, sorting, Surprise Me, the movie
  detail modal, watchlist, trailer/watch links — is your existing logic,
  now talking to a real backend instead of nothing.

---

## 7. Honest limits of "production-grade security"

This implements real, practical protections: hashed + expiring + rate-
limited OTPs, verified Google ID tokens, HttpOnly/SameSite session cookies,
session-fixation protection, CSRF via double-submit cookie, security
headers, input validation, and generic client-facing error messages with
full detail kept server-side only.

What it is *not*: a claim of "100% secure" (nothing is), a penetration
test, or a substitute for keeping dependencies updated over time
(`npm audit` periodically) and monitoring your logs once it's live.
